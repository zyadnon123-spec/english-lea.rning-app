import json,re,random,os,sys,urllib.request,urllib.parse,concurrent.futures as cf
sys.path.insert(0,'/tmp/work')
from extract import LV,STOP,wc,f
res=json.load(open('/tmp/work/phaseA.json'))
CACHE='/tmp/work/trcache.json'
cache=json.load(open(CACHE)) if os.path.exists(CACHE) else {}
def sq(k,r):
    return r
# ---- choose QA per story
def mmss(sec):
    sec=int(sec);h=sec//3600;m=sec%3600//60;s=sec%60
    return f"{h}:{m:02d}:{s:02d}" if h else f"{m}:{s:02d}"
def or_alts(q,a):
    qq=q.rstrip('?').strip()
    if ' or ' not in qq: return None
    left,right=qq.split(' or ',1)
    rw=right.split(); lw=left.split()
    if not rw or len(rw)>4 or len(lw)<2: return None
    pre={'from','about','in','at','on','to','for','with','a','an','the','by','of'}
    n=len(rw)
    if rw[0].lower() in pre:
        idxs=[i for i,w in enumerate(lw) if w.lower()==rw[0].lower()]
        if not idxs: lalt=lw[-n:]
        else: lalt=lw[idxs[-1]:]
    else: lalt=lw[-n:]
    if len(lalt)>n+3 or not lalt: return None
    L=' '.join(lalt).strip(' ,'); R=' '.join(rw).strip(' ,')
    an=a.lower()
    inL=L.lower() in an or (len(L.split())>1 and L.split()[-1].lower() in an.split()) 
    inR=R.lower() in an or (len(R.split())>1 and R.split()[-1].lower() in an.split())
    if inL==inR: return None
    return (L,R,L if inL else R)
for r in res:
    pool=[];seen=set()
    for x in r['qa']:
        q,a=x['q'],x['a']
        if q.lower() in seen: continue
        seen.add(q.lower())
        al=or_alts(q,a)
        if al: pool.append({**x,'type':'or','alts':al}); continue
        if ' or ' in q: continue
        m=re.match(r'(?i)(yes|no)\b',a.strip())
        if m and re.match(r'(?i)(is|are|was|were|do|does|did|can|will|has|have|should|could|would)\b',q): pool.append({**x,'type':'yn','ans':m.group(1).capitalize()})
    ors=[p for p in pool if p['type']=='or']; yns=[p for p in pool if p['type']=='yn']
    random.Random(r['k']).shuffle(ors); random.Random(r['k']+1).shuffle(yns)
    r['qa2']=(ors[:5]+yns[:4])
# ---- translation
need=set()
def add(s):
    s=s.strip()
    if s: need.add(s)
for r in res:
    add(r['title']); add(r['rule'])
    for v in r['vocab']: add(v['term'])
    for s in r['sentences']: add(s['en'])
    for e in r['grammar']['examples']: add(e)
    for x in r['qa2']: add(x['q'])
todo=[s for s in need if s not in cache]
print('strings',len(need),'todo',len(todo))
def post(lines):
    data=urllib.parse.urlencode({'q':'\n'.join(lines)}).encode()
    req=urllib.request.Request('https://translate.googleapis.com/translate_a/single?client=gtx&sl=en&tl=ar&dt=t',data=data)
    for _ in range(4):
        try:
            j=json.loads(urllib.request.urlopen(req,timeout=40).read())
            return ''.join(seg[0] for seg in j[0] if seg[0])
        except Exception as e: err=e
    return None
def batch(lines):
    out=post(lines)
    if out is not None:
        parts=out.split('\n')
        if len(parts)==len(lines): return dict(zip(lines,[p.strip() for p in parts]))
    d={}
    for l in lines:
        o=post([l]); d[l]=(o or '').replace('\n',' ').strip()
    return d
B=[todo[i:i+15] for i in range(0,len(todo),15)]
with cf.ThreadPoolExecutor(8) as ex:
    for n,d in enumerate(ex.map(batch,B)):
        cache.update(d)
        if n%100==0: print('batch',n,len(B),flush=True)
json.dump(cache,open(CACHE,'w'),ensure_ascii=False)
ar=lambda s: cache.get(s.strip(),'')
# ---- build
stories=[];questions=[]
def norm(s): return re.sub(r'[^a-z0-9 ]','',s.lower()).strip()
allv=[]
for r in res:
    for v in r['vocab']: allv.append(v['term'])
for r in res:
    k=r['k'];rng=random.Random(1000+k);li=k//35
    lv=LV[li]
    gtopic=(r['grammar']['topic'] or '').strip()
    gkey=norm(gtopic) or f'story{k+1}'
    vocab=[]
    sents=r['sentences']
    for v in r['vocab']:
        pat=re.compile(r'\b'+re.escape(v['term'])+r"(?:s|es|ed|d|ing)?\b",re.I)
        ex=next((s for s in sents if pat.search(s['en'])),None)
        vocab.append({'term':v['term'],'ar':ar(v['term']),'sec':v['sec'],'exEn':ex['en'] if ex else '','exAr':ar(ex['en']) if ex else '','exSec':ex['sec'] if ex else v['sec']})
    vocab=[v for v in vocab if v['ar']]
    ssents=[{'en':s['en'],'ar':ar(s['en']),'sec':s['sec']} for s in sents if ar(s['en'])]
    nk=min(8,len(ssents)); step=len(ssents)/max(nk,1)
    keyidx=set(int(i*step) for i in range(nk))
    for i,s in enumerate(ssents): s['key']=i in keyidx
    title=r['title'] or f'قصة {k+1}'
    st=dict(id=k+1,level=lv[0],levelName=lv[1],idx=k%35+1,title=title,titleAr=ar(r['title']) if r['title'] else '',book=r['book'],author=r['author'],
        startSec=r['S'],endSec=r['E'],grammar=dict(topic=gtopic,key=gkey,sec=r['grammar']['sec'],examples=[{'en':e,'ar':ar(e)} for e in r['grammar']['examples']]),
        rule=r['rule'],ruleAr=ar(r['rule']) if r['rule'] else '',vocab=vocab,sentences=ssents,lines=r['lines'])
    stories.append(st)
    Q=[]
    def add(kind,prompt,promptAr,options,answer,expl,sec,vocabTerm=None,gk=None,sub=''):
        Q.append(dict(storyId=k+1,kind=kind,sub=sub,prompt=prompt,promptAr=promptAr,options=options,answer=answer,explanation=expl,seekSec=int(sec),vocabTerm=vocabTerm,grammarKey=gk))
    # vocab mcq
    vpool=[v for v in vocab if v['ar'] and v['ar']!=v['term']]
    lvl_ar=[ar(w) for w in allv[max(0,li*0):] ] if False else []
    others=[v['ar'] for v in vocab]
    glob=[w for w in rng.sample(allv,min(40,len(allv)))]
    gl_ar=[ar(w) for w in glob if ar(w)]
    for v in vpool[:9]:
        ds=[x for x in dict.fromkeys(others+gl_ar) if x!=v['ar']]
        rng.shuffle(ds)
        opts=[v['ar']]+ds[:3]
        if len(opts)<3: continue
        rng.shuffle(opts)
        add('mcq',f'ما معنى كلمة "{v["term"]}"؟','',opts,v['ar'],f'"{v["term"]}" تعني «{v["ar"]}». سمعتها في القصة عند {mmss(v["sec"])}.',v['sec'],v['term'],None,'vocab')
    # cloze
    singles=[v['term'] for v in vocab if ' ' not in v['term']]
    cw=[]
    for s in ssents:
        for w in re.findall(r"[A-Za-z']+",s['en']):
            if len(w)>=4 and w.lower() not in STOP: cw.append(w.lower())
    cw=list(dict.fromkeys(cw))
    cands=[s for s in ssents if 5<=wc(s['en'])<=16]
    rng.shuffle(cands)
    n=0
    for s in cands:
        words=re.findall(r"[A-Za-z']+",s['en'])
        low=[w.lower() for w in words]
        vt=[w for w in singles if w in low]
        if vt: tgt=vt[0]; isv=True
        else:
            c=[w for w in low if len(w)>=4 and w not in STOP]
            if not c: continue
            tgt=rng.choice(c); isv=False
        ds=[w for w in dict.fromkeys(singles+cw) if w!=tgt and w not in low and abs(len(w)-len(tgt))<=4]
        rng.shuffle(ds)
        if len(ds)<3: continue
        sent=re.sub(r'\b'+re.escape(tgt)+r'\b','_____',s['en'],count=1,flags=re.I)
        if '_____' not in sent: continue
        opts=[tgt]+ds[:3]; rng.shuffle(opts)
        add('cloze',sent,s['ar'],opts,tgt,f'الجملة كاملة: "{s["en"]}" — {s["ar"]}',s['sec'],tgt if isv else None,None if isv else gkey)
        n+=1
        if n>=8: break
    # order
    oc=[s for s in ssents if 4<=wc(s['en'])<=11]
    rng.shuffle(oc)
    for s in oc[:6]:
        toks=s['en'].strip().rstrip('.!').split()
        chips=toks[:]
        for _ in range(10):
            rng.shuffle(chips)
            if chips!=toks: break
        add('order','رتّب الكلمات لتكوين الجملة',s['ar'],chips,' '.join(toks),f'الترتيب الصحيح: "{s["en"]}" — {s["ar"]}',s['sec'],None,gkey)
    # translate
    tc=[s for s in ssents if 4<=wc(s['en'])<=14]
    rng.shuffle(tc)
    for s in tc[:6]:
        ds=[x['ar'] for x in ssents if x['ar']!=s['ar']]
        ds=list(dict.fromkeys(ds)); rng.shuffle(ds)
        if len(ds)<3: continue
        opts=[s['ar']]+ds[:3]; rng.shuffle(opts)
        add('translate',s['en'],'',opts,s['ar'],f'"{s["en"]}" تعني: {s["ar"]}',s['sec'],None,gkey)
    # comprehension
    for x in r['qa2']:
        qa_ar=ar(x['q'])
        if x['type']=='or':
            L,R,c=x['alts']; opts=[L,R]; rng.shuffle(opts)
            add('mcq',x['q'],qa_ar,opts,c,f'إجابة المدرب في الفيديو: "{x["a"]}"',x['asec'],None,gkey,'comp')
        else:
            add('mcq',x['q'],qa_ar,['Yes','No'],x['ans'],f'إجابة المدرب في الفيديو: "{x["a"]}"',x['asec'],None,gkey,'comp')
    questions+=Q
print('stories',len(stories),'questions',len(questions))
from collections import Counter
print(Counter((q['kind'],q['sub']) for q in questions))
os.makedirs('/tmp/work/out',exist_ok=True)
json.dump({'stories':stories,'questions':questions},open('/tmp/work/out/content.json','w'),ensure_ascii=False,separators=(',',':'))
print(os.path.getsize('/tmp/work/out/content.json')/1e6,'MB')
# diag
mins=[sum(1 for q in questions if q['storyId']==i+1) for i in range(210)]
print('min q per story',min(mins))
for k in [0,100]:
    print(json.dumps([q for q in questions if q['storyId']==k+1][::6][:6],ensure_ascii=False)[:2500])
