import json,re,bisect
t=json.load(open('/tmp/tr.json'))
def f(x):
    x=int(x);return f"{x//3600:02d}:{x%3600//60:02d}:{x%60:02d}"
LV=[('A0','مستوى الأبجديات',300),('A1','مستوى التأسيس',19*3600+2*60+16),('A2','مستوى التواصل',36*3600+57*60),
    ('B1','مستوى الطلاقة',53*3600+13*60+17),('B2','مستوى الثقة',70*3600+13*60+26),('C1','مستوى الاحتراف',86*3600+3*60+46)]
END_ALL=100*3600+40*60+5
pos=[];buf=[];p=0
for i,s in enumerate(t):
    pos.append(p); buf.append(s['x']); p+=len(s['x'])+1
txt=' '.join(buf)
def idx(c): return bisect.bisect_right(pos,c)-1
ends=[]
for m in re.finditer(r'you practiced?\s+([\d,]+)\s+words\s+in\s+this\s+story',txt,re.I):
    ends.append(idx(m.start()))
assert len(ends)==210
bounds=[300]
for k,e in enumerate(ends):
    j=e
    while j<len(t)-1 and not re.search(r'learned a lot',t[j]['x'],re.I) and j<e+3: j+=1
    b=t[j+1]['t'] if j+1<len(t) else END_ALL
    bounds.append(int(round(b)))
# snap level boundaries
for li in range(1,6): bounds[li*35]=int(LV[li][2])
bounds[210]=END_ALL
def clean(x):
    x=re.sub(r'\[[^\]]*\]','',x); x=x.replace('>>',' ')
    x=re.sub(r'\s+',' ',x).strip()
    if re.fullmatch(r'(?i)foreign\.?|uh\.?|um\.?|yeah\.?',x): return ''
    return x
STOP=set("a an the is am are was were be been to of in on at it he she they we i you his her their my our your this that and or but for with as by from not no yes do does did".split())
def wc(s): return len(re.findall(r"[A-Za-z0-9']+",s))
def sentences_of(snips):
    # snips: list of (sec,text). returns list of (sec,text)
    ps=[];p=0;parts=[]
    for sec,x in snips:
        ps.append(p); parts.append(x); p+=len(x)+1
    tx=' '.join(parts)
    out=[]
    for m in re.finditer(r'[^.?!]+[.?!]+',tx):
        s=m.group(0).strip()
        st=m.start()+ (len(m.group(0))-len(m.group(0).lstrip()))
        k=bisect.bisect_right(ps,st)-1
        out.append((snips[max(k,0)][0],s))
    return out,tx
BAD=re.compile(r"^(congratulations|great|awesome|yes|no|let's|let us|please|okay|ok|so|thank|alhamdulillah|all right|now|amazing|good|nice|wow|and|but)\b",re.I)
stories=[]
for k in range(210):
    li=k//35
    S,E=bounds[k],bounds[k+1]
    snips=[(t[i]['t'],clean(t[i]['x'])) for i in range(len(t)) if S<=t[i]['t']<E] if False else None
    stories.append({'k':k,'S':S,'E':E})
# index snippets by time
times=[s['t'] for s in t]
for st in stories:
    a=bisect.bisect_left(times,st['S']); b=bisect.bisect_left(times,st['E'])
    st['snips']=[(int(times[i]),clean(t[i]['x'])) for i in range(a,b) if clean(t[i]['x'])]
def process(st):
    k=st['k'];li=k//35;S=st['S'];E=st['E']
    snips=st['snips']
    ps=[];p=0
    for sec,x in snips: ps.append(p); p+=len(x)+1
    tx=' '.join(x for _,x in snips)
    title=book=author='';vocab_from=0
    m=re.search(r'from the book[,.?]?\s+',tx,re.I)
    if m and m.start()<len(tx):
        before=tx[:m.start()]
        # sentence prefix
        seg=re.split(r'(?<=[.?!])\s+',before)
        seg=[x.strip(' ,.') for x in seg if x.strip(' ,.')]
        title=seg[-1] if seg else ''
        if wc(title)>9 and len(seg)>1: title=seg[-2]
        h=title.split()
        if len(h)%2==0 and len(h)>=2 and [w.lower() for w in h[:len(h)//2]]==[w.lower() for w in h[len(h)//2:]]: title=' '.join(h[:len(h)//2])
        rest=tx[m.end():]
        mb=re.match(r'(.{3,90}?)\s+by\s+([A-Z][A-Za-z\'\- ]{2,40}?)(?:[.,]|$)',rest) or re.match(r'(.{3,90}?)\s+by\s+([A-Z][A-Za-z\']+(?: [A-Z][A-Za-z\']+){0,2})',rest)
        if mb:
            book=mb.group(1).strip(' ,.'); author=' '.join(mb.group(2).split()[:4]).strip(' ,.')
            endc=m.end()+mb.end()
        else:
            mm=re.match(r'[^.?!]{3,100}[.?!]',rest)
            book=mm.group(0).strip(' ,.?!') if mm else ''
            endc=m.end()+(mm.end() if mm else 0)
        vocab_from=bisect.bisect_right(ps,endc)-1
        vocab_from=max(vocab_from,0)
        # advance past the snippet containing the author end
        vocab_from+=1
    else:
        mm=re.search(r'tells (?:it|their story|the story) in (.{3,60}?)[.]',tx)
        if mm: book=mm.group(1)
    # vocab
    def collect(vocab_from):
        terms=[];i=vocab_from;prev_t=None;vend=vocab_from
        while i<len(snips):
            sec,x=snips[i]
            if wc(x)>3:
                if terms: break
                if sec-snips[vocab_from][0]>60: break
                i+=1; continue
            if prev_t is not None and sec-prev_t>40 and terms: break
            prev_t=sec
            for seg in re.split(r'[.,;:!]',x):
                seg=seg.strip()
                if seg: terms.append((seg,sec))
            i+=1; vend=i
        vocab=[];seen=set()
        for seg,sec in terms:
            ws=re.findall(r"[A-Za-z']+",seg)
            if not ws: continue
            cands=[' '.join(ws)] if (li>=3 and len(ws)<=3) or len(ws)==1 else ws
            for c in cands:
                c=c.lower()
                if c in STOP or len(c)<3 or c in seen or c in ('speaking','awesome','alhamdulillah','okay','right','please','good','great','wow','congratulations','ation','foreign'): continue
                seen.add(c); vocab.append({'term':c,'sec':sec})
        return vocab[:16],vend
    vocab,vend=collect(vocab_from)
    if len(vocab)<4:
        i=0
        while i<len(snips):
            if wc(snips[i][1])<=3:
                j=i
                while j+1<len(snips) and wc(snips[j+1][1])<=3 and snips[j+1][0]-snips[j][0]<15: j+=1
                if j-i+1>=7:
                    v2,e2=collect(i)
                    if len(v2)>=len(vocab): vocab,vend=v2,e2
                    break
                i=j+1
            else: i+=1
    # story region
    reg=snips[vend:]
    sents,rtx=sentences_of(reg)
    # grammar
    gram={'topic':'','examples':[],'sec':0}
    mg=None
    for mm in re.finditer(r'grammar we practiced?(?: today)?[,.:]?\s*',rtx,re.I): mg=mm
    rule=''
    mr=re.search(r'one rule for today[.,:]?\s*(.{5,160}?[.?!])',rtx,re.I)
    if mr: rule=mr.group(1).strip()
    story_end_c=len(rtx)
    if mg:
        after=rtx[mg.end():]
        after=re.split(r'(?i)congratulations',after)[0]
        ss=[x.strip() for x in re.findall(r'[^.?!]+[.?!]*',after) if x.strip()]
        sec=None
        kk=bisect.bisect_right([0]+[0],0)
        # time of marker
        rp=[];p2=0
        for s_,x_ in reg: rp.append(p2); p2+=len(x_)+1
        gram['sec']=reg[max(bisect.bisect_right(rp,mg.start())-1,0)][0]
        if ss:
            first=ss[0].strip(' .,')
            ws=first.split()
            nz=lambda x: re.sub(r'[^a-z]','',x.lower())
            sn={nz(x) for _,x in sents if not x.endswith('?')}
            topic=None
            if len(ws)>=2:
                for kk in range(1,min(len(ws),7)):
                    tail=' '.join(ws[kk:])
                    if wc(tail)>=3 and nz(tail) in sn:
                        topic=' '.join(ws[:kk]); ex=[tail]+ss[1:]; break
            if topic is None:
                if len(ws)>6: topic=' '.join(ws[:3]); ex=[' '.join(ws[3:])]+ss[1:]
                else: topic=first; ex=ss[1:]
            gram['topic']=topic; gram['examples']=[e.strip() for e in ex if wc(e)>=3][:5]
        cutc=mg.start()
    else: cutc=len(rtx)
    # candidate story sentences
    norm=lambda s: re.sub(r'[^a-z]','',s.lower())
    cnt={}
    for sec,s in sents:
        if s.endswith('?'): continue
        cnt[norm(s)]=cnt.get(norm(s),0)+1
    cand=[];seen=set()
    for sec,s in sents:
        if s.endswith('?'): continue
        s2=s.strip(' ')
        n=wc(s2)
        if n<4 or n>22 or BAD.match(s2) or re.search(r'(?i)congrat|story|alhamdulillah|grammar|chapter|video|youtube|question',s2): continue
        key=norm(s2)
        if key in seen: continue
        seen.add(key)
        cand.append({'en':s2,'sec':sec,'rep':cnt[key]})
    good=[c for c in cand if c['rep']>=2]
    if len(good)<8: good=cand
    # limit to 26 by even spread
    if len(good)>26:
        step=len(good)/26; good=[good[int(i*step)] for i in range(26)]
    # QA pairs
    qa=[]
    for ii,(sec,s) in enumerate(sents):
        if not s.endswith('?'): continue
        q=re.sub(r'^[^A-Za-z]*','',s).strip()
        if wc(q)<3 or wc(q)>16: continue
        # find answer: next sentences
        ans=None;ans_sec=sec
        for jj in range(ii+1,min(ii+4,len(sents))):
            if sents[jj][0]-sec>60: break
            if sents[jj][1].endswith('?'): break
            ans=sents[jj][1]; ans_sec=sents[jj][0]
            break
        if ans: qa.append({'q':q,'a':ans,'sec':sec,'asec':ans_sec})
    # transcript lines
    lines='\n'.join(f"{sec}|{x}" for sec,x in snips)
    return dict(title=title,book=book,author=author,vocab=vocab,grammar=gram,rule=rule,sentences=good,qa=qa,lines=lines)
if __name__=='__main__':
    import sys
    res=[]
    for st in stories:
        r=process(st); r.update(k=st['k'],S=st['S'],E=st['E']); res.append(r)
    json.dump(res,open('/tmp/work/phaseA.json','w'))
    nov=[r['k'] for r in res if len(r['vocab'])<4]; nots=[r['k'] for r in res if not r['title']]
    nog=[r['k'] for r in res if not r['grammar']['topic']]; nos=[r['k'] for r in res if len(r['sentences'])<8]
    print('few vocab',nov);print('no title',nots);print('no gram',nog);print('few sent',nos)
    print('qa avg',sum(len(r['qa']) for r in res)/210, 'min',min(len(r['qa']) for r in res))
    for k in [0,1,2,34,35,70,105,140,175,209]:
        r=res[k]; print(k,f(r['S']),f(r['E']),'|',r['title'],'|',r['book'],'|',r['author'],'|',[v['term'] for v in r['vocab']],'|',r['grammar']['topic'],r['grammar']['examples'][:2],'|',r['rule'][:60],len(r['sentences']),len(r['qa']))
