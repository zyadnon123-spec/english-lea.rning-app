import { db } from "@/db";
import * as S from "@/db/schema";
import { eq, and, asc, desc, inArray, sql, lte } from "drizzle-orm";
import { ensureSeed } from "./seed";

export const LEVELS = ["A0", "A1", "A2", "B1", "B2", "C1"] as const;
export const PASS = 70;
export const TZ = "Africa/Cairo";

/* ---------- التواريخ ---------- */
export function today() {
  return new Date().toLocaleDateString("en-CA", { timeZone: TZ });
}
export function addDays(d: string, n: number) {
  const x = new Date(d + "T00:00:00Z");
  x.setUTCDate(x.getUTCDate() + n);
  return x.toISOString().slice(0, 10);
}
function dow(d: string) {
  return new Date(d + "T00:00:00Z").getUTCDay();
}
export function nextStudyDate(from: string, rest: number[]) {
  let d = from;
  for (let i = 0; i < 14; i++) {
    if (!rest.includes(dow(d))) return d;
    d = addDays(d, 1);
  }
  return from;
}

/* ---------- القصص (خفيفة) ---------- */
export type Lite = {
  id: number;
  level: string;
  idx: number;
  title: string;
  titleAr: string;
  startSec: number;
  endSec: number;
  dur: number;
};
let liteCache: Lite[] | null = null;
export async function getLite(): Promise<Lite[]> {
  await ensureSeed();
  if (!liteCache) {
    const rows = await db
      .select({
        id: S.stories.id,
        level: S.stories.level,
        idx: S.stories.idx,
        title: S.stories.title,
        titleAr: S.stories.titleAr,
        startSec: S.stories.startSec,
        endSec: S.stories.endSec,
      })
      .from(S.stories)
      .orderBy(asc(S.stories.id));
    liteCache = rows.map((r) => ({ ...r, dur: r.endSec - r.startSec }));
  }
  return liteCache;
}

/* ---------- محرك الخطة ---------- */
export type FDay = {
  kind: "study" | "level_exam";
  level: string;
  storyIds: number[];
  plannedMin: number;
  targetMin: number;
  multiplier: number;
};

/** يختار آخر قصة كاملة أقرب لوقت المستخدم (±25%)، ولو باقي المستوى < 30 دقيقة يقفل عندها */
export function pickDay(rem: Lite[], targetMin: number): Lite[] {
  const T = targetMin * 60;
  let cum = 0;
  const sums: number[] = [];
  for (const s of rem) {
    cum += s.dur;
    sums.push(cum);
  }
  let best = 0;
  let bestD = Infinity;
  let inWin = false;
  for (let i = 0; i < sums.length; i++) {
    const d = Math.abs(sums[i] - T);
    const w = sums[i] >= T * 0.75 && sums[i] <= T * 1.25;
    if (w && (!inWin || d < bestD)) {
      best = i;
      bestD = d;
      inWin = true;
    } else if (!inWin && d < bestD) {
      best = i;
      bestD = d;
    }
    if (sums[i] > T * 1.25) break;
  }
  let cnt = best + 1;
  const left = cum - sums[cnt - 1];
  if (left > 0 && left < 30 * 60) cnt = rem.length;
  return rem.slice(0, cnt);
}

export function buildFuture(
  all: Lite[],
  covered: Set<number>,
  examLevels: Set<string>,
  baseMin: number,
  firstMult: number,
): FDay[] {
  const out: FDay[] = [];
  let first = true;
  for (const lv of LEVELS) {
    const lvStories = all.filter((s) => s.level === lv);
    let rem = lvStories.filter((s) => !covered.has(s.id));
    while (rem.length) {
      const mult = first ? firstMult : 1;
      first = false;
      const tgt = Math.max(15, Math.round(baseMin * mult));
      const pick = pickDay(rem, tgt);
      out.push({
        kind: "study",
        level: lv,
        storyIds: pick.map((s) => s.id),
        plannedMin: Math.round(pick.reduce((a, s) => a + s.dur, 0) / 60),
        targetMin: tgt,
        multiplier: mult,
      });
      rem = rem.slice(pick.length);
    }
    if (!examLevels.has(lv)) {
      first = false;
      out.push({
        kind: "level_exam",
        level: lv,
        storyIds: lvStories.map((s) => s.id),
        plannedMin: 25,
        targetMin: 25,
        multiplier: 1,
      });
    }
  }
  return out;
}

export function baseMinutes(minutesPerDay: number) {
  return minutesPerDay > 0 ? minutesPerDay : 45;
}

/** تقدير أولي من حدود المستويات فقط (قبل تحليل القصص) */
export const LEVEL_BOUNDS = [
  { level: "A0", from: 300, to: 19 * 3600 + 2 * 60 + 16 },
  { level: "A1", from: 19 * 3600 + 2 * 60 + 16, to: 36 * 3600 + 57 * 60 },
  { level: "A2", from: 36 * 3600 + 57 * 60, to: 53 * 3600 + 13 * 60 + 17 },
  { level: "B1", from: 53 * 3600 + 13 * 60 + 17, to: 70 * 3600 + 13 * 60 + 26 },
  { level: "B2", from: 70 * 3600 + 13 * 60 + 26, to: 86 * 3600 + 3 * 60 + 46 },
  { level: "C1", from: 86 * 3600 + 3 * 60 + 46, to: 100 * 3600 + 40 * 60 + 5 },
];
export function roughEstimate(baseMin: number) {
  return LEVEL_BOUNDS.reduce(
    (a, l) => a + Math.ceil((l.to - l.from) / 60 / baseMin) + 1,
    0,
  );
}

export function assignDates(count: number, start: string, rest: number[]) {
  const dates: string[] = [];
  let d = nextStudyDate(start, rest);
  for (let i = 0; i < count; i++) {
    dates.push(d);
    d = nextStudyDate(addDays(d, 1), rest);
  }
  return dates;
}

/* ---------- الإعدادات ---------- */
export type SettingsRow = typeof S.settings.$inferSelect;
export async function getSettings(): Promise<SettingsRow> {
  await ensureSeed();
  const [s] = await db.select().from(S.settings).where(eq(S.settings.id, 1));
  return s;
}
export const restOf = (s: SettingsRow) => (s.restDays as number[]) ?? [];

export type PlanDayRow = typeof S.planDays.$inferSelect;

async function activitySet() {
  const rows = await db.select().from(S.activity);
  return new Set(rows.map((r) => r.date));
}

export async function touchActivity() {
  const d = today();
  await db
    .insert(S.activity)
    .values({ date: d, actions: 1 })
    .onConflictDoUpdate({
      target: S.activity.date,
      set: { actions: sql`${S.activity.actions} + 1` },
    });
}

/** يحمّل الخطة: الأيام المنتهية + اليوم النشط + الأيام القادمة (متجددة) */
export async function loadPlan() {
  const settings = await getSettings();
  const all = await getLite();
  const rest = restOf(settings);
  const t = today();
  let days = await db.select().from(S.planDays).orderBy(asc(S.planDays.dayNo));
  const examLevels = () =>
    new Set(days.filter((d) => d.kind === "level_exam").map((d) => d.level));
  const coveredSet = () => {
    const c = new Set<number>();
    for (const d of days) if (d.kind === "study") (d.storyIds as number[]).forEach((i) => c.add(i));
    return c;
  };
  let active = days.find((d) => d.status === "active") ?? null;

  if (settings.started && !active) {
    const fut = buildFuture(
      all,
      coveredSet(),
      examLevels(),
      baseMinutes(settings.minutesPerDay),
      settings.nextMultiplier,
    );
    if (fut.length) {
      const lastDone = [...days].reverse().find((d) => d.status === "done");
      const from = lastDone?.completedDate
        ? addDays(lastDone.completedDate, 1)
        : t;
      const sched = nextStudyDate(from > t ? from : t, rest);
      const f = fut[0];
      const [ins] = await db
        .insert(S.planDays)
        .values({
          dayNo: days.length + 1,
          kind: f.kind,
          level: f.level,
          storyIds: f.storyIds,
          targetMin: f.targetMin,
          plannedMin: f.plannedMin,
          multiplier: f.multiplier,
          scheduledDate: sched,
        })
        .returning();
      await db.update(S.settings).set({ nextMultiplier: 1 }).where(eq(S.settings.id, 1));
      settings.nextMultiplier = 1;
      days = [...days, ins];
      active = ins;
    }
  }
  if (active && active.scheduledDate < t) {
    const sched = nextStudyDate(t, rest);
    await db.update(S.planDays).set({ scheduledDate: sched }).where(eq(S.planDays.id, active.id));
    active = { ...active, scheduledDate: sched };
    days = days.map((d) => (d.id === active!.id ? active! : d));
  }

  const future = settings.started
    ? buildFuture(
        all,
        coveredSet(),
        examLevels(),
        baseMinutes(settings.minutesPerDay),
        settings.nextMultiplier,
      )
    : [];
  const startDate = active
    ? addDays(active.scheduledDate, 1)
    : t;
  const futDates = assignDates(future.length, startDate, rest);
  const futureDays = future.map((f, i) => ({
    ...f,
    dayNo: days.length + i + 1,
    date: futDates[i],
  }));
  return {
    settings,
    all,
    done: days.filter((d) => d.status === "done"),
    active,
    futureDays,
    totalDays: days.length + futureDays.length,
    today: t,
  };
}

/* ---------- نقاط الضعف / الدرجات ---------- */
export async function weakMap() {
  const rows = await db.select().from(S.weakness);
  const m = new Map<string, number>();
  for (const w of rows) {
    if (w.wrong > 0) m.set(`${w.kind}:${w.key}`, w.wrong / Math.max(w.attempts, 1));
  }
  return m;
}

export type QRow = typeof S.questions.$inferSelect;

/** اختيار أسئلة متنوعة: يوزّع على القصص وعلى الأنواع ويفضّل نقاط الضعف وأخطاء المحاولة السابقة */
export function pickQuestions(
  rows: QRow[],
  n: number,
  weak: Map<string, number>,
  prevWrong: Set<number>,
): QRow[] {
  const pool = rows.map((q) => {
    let w = Math.random();
    if (q.vocabTerm && weak.has(`word:${q.vocabTerm}`)) w += 1.2 * (weak.get(`word:${q.vocabTerm}`) ?? 0);
    if (q.grammarKey && weak.has(`grammar:${q.grammarKey}`)) w += 0.8 * (weak.get(`grammar:${q.grammarKey}`) ?? 0);
    if (prevWrong.has(q.id)) w += 1.5;
    return { q, w };
  });
  const perStory = new Map<number, number>();
  const perKind = new Map<string, number>();
  const out: QRow[] = [];
  const target = Math.min(n, pool.length);
  const kindCap = Math.ceil(n * 0.45);
  while (out.length < target && pool.length) {
    let bi = 0;
    let bs = -Infinity;
    for (let i = 0; i < pool.length; i++) {
      const { q, w } = pool[i];
      const kk = `${q.kind}:${q.sub}`;
      const kc = perKind.get(kk) ?? 0;
      if (kc >= kindCap && pool.some((p) => (perKind.get(`${p.q.kind}:${p.q.sub}`) ?? 0) < kindCap)) continue;
      const s = w - 0.9 * (perStory.get(q.storyId) ?? 0) - 0.55 * kc;
      if (s > bs) {
        bs = s;
        bi = i;
      }
    }
    const [{ q }] = pool.splice(bi, 1);
    out.push(q);
    perStory.set(q.storyId, (perStory.get(q.storyId) ?? 0) + 1);
    const kk = `${q.kind}:${q.sub}`;
    perKind.set(kk, (perKind.get(kk) ?? 0) + 1);
  }
  // اخلط الترتيب النهائي قليلًا بحيث لا تتتابع نفس القصة
  return out.sort(() => Math.random() - 0.5);
}

/* ---------- بطاقات المراجعة ---------- */
export async function ensureStoryCards(storyId: number, due: string) {
  const vs = await db.select().from(S.vocab).where(eq(S.vocab.storyId, storyId));
  const ss = await db
    .select()
    .from(S.sentences)
    .where(and(eq(S.sentences.storyId, storyId), eq(S.sentences.isKey, true)));
  const rows = [
    ...vs.map((v) => ({
      kind: "word",
      refId: v.id,
      storyId,
      front: v.term,
      back: v.ar,
      example: v.exEn,
      sourceSec: v.sec,
      dueDate: due,
    })),
    ...ss.slice(0, 5).map((x) => ({
      kind: "sentence",
      refId: x.id,
      storyId,
      front: x.en,
      back: x.ar,
      example: "",
      sourceSec: x.sec,
      dueDate: due,
    })),
  ];
  if (rows.length) await db.insert(S.reviewCards).values(rows).onConflictDoNothing();
}

export async function boostCard(kind: "word" | "sentence", refId: number, storyId: number, due: string) {
  // يضمن وجود البطاقة ويجعل موعدها لا يتأخر عن due
  if (kind === "word") {
    const [v] = await db.select().from(S.vocab).where(eq(S.vocab.id, refId));
    if (!v) return;
    await db
      .insert(S.reviewCards)
      .values({ kind, refId, storyId, front: v.term, back: v.ar, example: v.exEn, sourceSec: v.sec, dueDate: due })
      .onConflictDoNothing();
  } else {
    const [x] = await db.select().from(S.sentences).where(eq(S.sentences.id, refId));
    if (!x) return;
    await db
      .insert(S.reviewCards)
      .values({ kind, refId, storyId, front: x.en, back: x.ar, example: "", sourceSec: x.sec, dueDate: due })
      .onConflictDoNothing();
  }
  await db
    .update(S.reviewCards)
    .set({ dueDate: sql`least(${S.reviewCards.dueDate}, ${due})`, intervalDays: 0 })
    .where(and(eq(S.reviewCards.kind, kind), eq(S.reviewCards.refId, refId)));
}

/* ---------- إحصاءات ---------- */
export async function streakOf(rest: number[]) {
  const act = await activitySet();
  const t = today();
  let d = act.has(t) ? t : addDays(t, -1);
  let n = 0;
  for (let i = 0; i < 500; i++) {
    if (act.has(d)) n++;
    else if (!rest.includes(dow(d))) break;
    d = addDays(d, -1);
  }
  return n;
}

export async function missedStudyDates(startDate: string | null, rest: number[]) {
  if (!startDate) return [] as string[];
  const act = await activitySet();
  const t = today();
  const out: string[] = [];
  let d = startDate;
  for (let i = 0; i < 800 && d < t; i++) {
    if (!rest.includes(dow(d)) && !act.has(d)) out.push(d);
    d = addDays(d, 1);
  }
  return out;
}

export async function dueCount() {
  const t = today();
  const [r] = await db
    .select({ c: sql<number>`count(*)::int` })
    .from(S.reviewCards)
    .where(lte(S.reviewCards.dueDate, t));
  return r.c;
}

export async function weakList(limit = 12) {
  const rows = await db
    .select()
    .from(S.weakness)
    .where(sql`${S.weakness.wrong} > 0`);
  return rows
    .map((w) => ({ ...w, rate: Math.round((w.wrong / Math.max(w.attempts, 1)) * 100) }))
    .sort((a, b) => b.rate - a.rate || b.wrong - a.wrong)
    .slice(0, limit);
}

export { eq, and, asc, desc, inArray, sql, lte };
