"use client";
import { useCallback, useEffect, useState } from "react";
import { useRouter } from "next/navigation";

export const VIDEO_ID = "nSrjNHK6slw";

export async function api<T>(url: string, init?: RequestInit): Promise<T> {
  const r = await fetch(url, {
    ...init,
    headers: { "Content-Type": "application/json", ...(init?.headers ?? {}) },
    cache: "no-store",
  });
  if (!r.ok) throw new Error(String(r.status));
  return (await r.json()) as T;
}

export function post<T>(url: string, body: unknown) {
  return api<T>(url, { method: "POST", body: JSON.stringify(body) });
}

export function fmtSec(sec: number) {
  sec = Math.max(0, Math.floor(sec));
  const h = Math.floor(sec / 3600);
  const m = Math.floor((sec % 3600) / 60);
  const s = sec % 60;
  const p = (n: number) => String(n).padStart(2, "0");
  return h ? `${h}:${p(m)}:${p(s)}` : `${m}:${p(s)}`;
}

export function fmtMin(min: number) {
  if (min < 60) return `${min} دقيقة`;
  const h = Math.floor(min / 60);
  const m = min % 60;
  const hs = h === 1 ? "ساعة" : h === 2 ? "ساعتان" : `${h} ساعات`;
  return m ? `${hs} و${m} دقيقة` : hs;
}

export function fmtDate(iso: string, opts?: Intl.DateTimeFormatOptions) {
  return new Date(iso + "T00:00:00").toLocaleDateString("ar-EG-u-nu-latn", {
    weekday: "long",
    day: "numeric",
    month: "long",
    ...opts,
  });
}

export const ytLink = (sec: number) =>
  `https://www.youtube.com/watch?v=${VIDEO_ID}&t=${Math.floor(sec)}s`;

export const isAr = (s: string) => /[\u0600-\u06FF]/.test(s);

export function useApi<T>(url: string | null) {
  const [data, setData] = useState<T | null>(null);
  const [error, setError] = useState(false);
  const [tick, setTick] = useState(0);
  useEffect(() => {
    if (!url) return;
    let dead = false;
    api<T>(url)
      .then((d) => !dead && (setData(d), setError(false)))
      .catch(() => !dead && setError(true));
    return () => {
      dead = true;
    };
  }, [url, tick]);
  const reload = useCallback(() => setTick((t) => t + 1), []);
  return { data, error, reload };
}

export type DayStory = {
  id: number;
  title: string;
  titleAr: string;
  idx: number;
  level: string;
  startSec: number;
  endSec: number;
  durMin: number;
  practiced: boolean;
  bestScore: number;
};

export type AppState =
  | { started: false; finished?: boolean }
  | {
      started: true;
      today: string;
      day: {
        id: number;
        dayNo: number;
        kind: "study" | "level_exam";
        level: string;
        levelName: string;
        plannedMin: number;
        targetMin: number;
        multiplier: number;
        scheduledDate: string;
        attempts: number;
        bestScore: number | null;
        stories: DayStory[];
        practiced: number;
        progress: number;
        examStories: number;
        examList: { id: number; idx: number; title: string }[];
      };
      notes: string[];
      stats: {
        streak: number;
        avgQuiz: number;
        quizCount: number;
        level: string;
        levelName: string;
        levelDone: number;
        levelTotal: number;
      };
      review: { due: number; weak: number };
      totalDays: number;
      doneDays: number;
      finishDate: string;
      minutesPerDay: number;
    };

export type StartedState = Extract<AppState, { started: true }>;

/** يجلب حالة التطبيق ويحوّل لشاشة الخطة إن لم تبدأ */
export function useAppState() {
  const router = useRouter();
  const r = useApi<AppState>("/api/state");
  useEffect(() => {
    if (r.data && !r.data.started) router.replace("/plan");
  }, [r.data, router]);
  return {
    state: r.data && r.data.started ? (r.data as StartedState) : null,
    loading: !r.data && !r.error,
    error: r.error,
    reload: r.reload,
  };
}

export type Question = {
  id: number;
  storyId: number;
  kind: "mcq" | "cloze" | "order" | "translate";
  sub: string;
  prompt: string;
  promptAr: string;
  options: string[];
  answer: string;
  explanation: string;
  seekSec: number;
};

export const KIND_LABEL: Record<string, string> = {
  mcq: "اختيار من متعدد",
  cloze: "إكمال جملة",
  order: "ترتيب كلمات",
  translate: "ترجمة",
};
