import fs from "fs";
import path from "path";
import { sql } from "drizzle-orm";
import { db } from "@/db";
import * as S from "@/db/schema";

type RawStory = {
  id: number;
  level: string;
  levelName: string;
  idx: number;
  title: string;
  titleAr: string;
  book: string;
  author: string;
  startSec: number;
  endSec: number;
  grammar: unknown;
  rule: string;
  ruleAr: string;
  lines: string;
  vocab: {
    term: string;
    ar: string;
    sec: number;
    exEn: string;
    exAr: string;
    exSec: number;
  }[];
  sentences: { en: string; ar: string; sec: number; key: boolean }[];
};

type RawQuestion = {
  storyId: number;
  kind: string;
  sub: string;
  prompt: string;
  promptAr: string;
  options: string[];
  answer: string;
  explanation: string;
  seekSec: number;
  vocabTerm: string | null;
  grammarKey: string | null;
};

let seeding: Promise<void> | null = null;

export function ensureSeed(): Promise<void> {
  if (!seeding) {
    seeding = doSeed().catch((e) => {
      seeding = null;
      throw e;
    });
  }
  return seeding;
}

async function chunked<T>(rows: T[], size: number, fn: (c: T[]) => Promise<unknown>) {
  for (let i = 0; i < rows.length; i += size) await fn(rows.slice(i, i + size));
}

async function doSeed() {
  await db.insert(S.settings).values({ id: 1 }).onConflictDoNothing();
  const r = await db.execute(sql`select count(*)::int as c from stories`);
  const c = Number((r.rows[0] as { c: number }).c);
  const q = await db.execute(sql`select count(*)::int as c from questions`);
  if (c >= 210 && Number((q.rows[0] as { c: number }).c) > 5000) return;

  const file = path.join(process.cwd(), "data", "content.json");
  const data = JSON.parse(fs.readFileSync(file, "utf8")) as {
    stories: RawStory[];
    questions: RawQuestion[];
  };

  await db.transaction(async (tx) => {
    await tx.execute(sql`truncate table stories, vocab, sentences, questions restart identity`);
    await chunked(data.stories, 15, (ch) =>
      tx.insert(S.stories).values(
        ch.map((s) => ({
          id: s.id,
          level: s.level,
          levelName: s.levelName,
          idx: s.idx,
          title: s.title,
          titleAr: s.titleAr,
          book: s.book,
          author: s.author,
          startSec: s.startSec,
          endSec: s.endSec,
          grammar: s.grammar,
          rule: s.rule,
          ruleAr: s.ruleAr,
          lines: s.lines,
        })),
      ),
    );
    const vrows = data.stories.flatMap((s) =>
      s.vocab.map((v) => ({ storyId: s.id, ...v })),
    );
    await chunked(vrows, 500, (ch) => tx.insert(S.vocab).values(ch));
    const srows = data.stories.flatMap((s) =>
      s.sentences.map((x) => ({
        storyId: s.id,
        en: x.en,
        ar: x.ar,
        sec: x.sec,
        isKey: x.key,
      })),
    );
    await chunked(srows, 500, (ch) => tx.insert(S.sentences).values(ch));
    await chunked(data.questions, 500, (ch) => tx.insert(S.questions).values(ch));
  });
}
