"use client";
import { useEffect, useRef, useState } from "react";
import { VIDEO_ID, fmtSec, ytLink } from "@/lib/client";

type YTP = {
  loadVideoById: (o: { videoId: string; startSeconds: number; endSeconds?: number }) => void;
  destroy: () => void;
};
declare global {
  interface Window {
    YT?: { Player: new (el: HTMLElement, o: unknown) => YTP };
    onYouTubeIframeAPIReady?: () => void;
  }
}

let ytPromise: Promise<void> | null = null;
function loadYT(): Promise<void> {
  if (typeof window === "undefined") return Promise.reject();
  if (window.YT?.Player) return Promise.resolve();
  if (!ytPromise) {
    ytPromise = new Promise<void>((res, rej) => {
      const prev = window.onYouTubeIframeAPIReady;
      window.onYouTubeIframeAPIReady = () => {
        prev?.();
        res();
      };
      const s = document.createElement("script");
      s.src = "https://www.youtube.com/iframe_api";
      s.onerror = () => {
        ytPromise = null;
        rej(new Error("blocked"));
      };
      document.head.appendChild(s);
      setTimeout(() => rej(new Error("timeout")), 10000);
    });
  }
  return ytPromise;
}

/** مشغّل يوتيوب مضمّن يعمل من start إلى end، مع seek لثانية معيّنة. لو التضمين اتمنع يعرض رابطًا يفتح عند الوقت. */
export default function YTPlayer({
  start,
  end,
  seek,
  compact,
  autoplay,
}: {
  start: number;
  end: number;
  seek?: { sec: number; key: number } | null;
  compact?: boolean;
  autoplay?: boolean;
}) {
  const holder = useRef<HTMLDivElement>(null);
  const player = useRef<YTP | null>(null);
  const [failed, setFailed] = useState(false);
  const [ready, setReady] = useState(false);
  const [cur, setCur] = useState(start);

  useEffect(() => {
    let dead = false;
    setFailed(false);
    setReady(false);
    setCur(start);
    loadYT()
      .then(() => {
        if (dead || !holder.current || !window.YT) return;
        holder.current.innerHTML = "";
        const div = document.createElement("div");
        holder.current.appendChild(div);
        player.current = new window.YT.Player(div, {
          videoId: VIDEO_ID,
          width: "100%",
          height: "100%",
          playerVars: {
            start: Math.floor(start),
            end: Math.floor(end),
            rel: 0,
            playsinline: 1,
            modestbranding: 1,
            autoplay: autoplay ? 1 : 0,
          },
          events: {
            onReady: () => !dead && setReady(true),
            onError: () => !dead && setFailed(true),
          },
        });
      })
      .catch(() => !dead && setFailed(true));
    return () => {
      dead = true;
      try {
        player.current?.destroy();
      } catch {}
      player.current = null;
    };
  }, [start, end]);

  useEffect(() => {
    if (!seek) return;
    setCur(seek.sec);
    if (player.current?.loadVideoById) {
      player.current.loadVideoById({
        videoId: VIDEO_ID,
        startSeconds: Math.floor(seek.sec),
        endSeconds: Math.floor(end),
      });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [seek?.key]);

  return (
    <div>
      {!failed ? (
        <div
          className={`relative w-full overflow-hidden rounded-2xl bg-black ${compact ? "aspect-video" : "aspect-video"}`}
        >
          <div ref={holder} className="absolute inset-0 [&_iframe]:h-full [&_iframe]:w-full" />
          {!ready && (
            <div className="absolute inset-0 flex items-center justify-center text-xs text-white/70">
              جارِ تحميل المشغّل…
            </div>
          )}
        </div>
      ) : (
        <div className="card flex flex-col items-center gap-3 p-5 text-center">
          <p className="text-sm text-muted">تعذّر تضمين الفيديو هنا. افتحه مباشرة عند الوقت المطلوب:</p>
          <a className="btn btn-accent w-full" href={ytLink(cur)} target="_blank" rel="noreferrer">
            ▶ افتح يوتيوب عند {fmtSec(cur)}
          </a>
        </div>
      )}
      <p className="mt-2 text-center text-[12px] text-muted">
        المقطع من {fmtSec(start)} إلى {fmtSec(end)} —{" "}
        <a className="text-brand underline" href={ytLink(seek?.sec ?? start)} target="_blank" rel="noreferrer">
          افتح في يوتيوب
        </a>
      </p>
    </div>
  );
}
