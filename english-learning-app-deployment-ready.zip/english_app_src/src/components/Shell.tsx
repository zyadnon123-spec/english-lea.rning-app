"use client";
import Link from "next/link";
import type { ReactNode } from "react";

const ITEMS = [
  { key: "home", href: "/", label: "الرئيسية", d: "M3 11l9-8 9 8v9a1 1 0 01-1 1h-5v-6H9v6H4a1 1 0 01-1-1z" },
  { key: "lesson", href: "/lesson", label: "الدرس", d: "M5 4h11a3 3 0 013 3v13H8a3 3 0 01-3-3zM5 17a3 3 0 013-3h11" },
  { key: "practice", href: "/practice", label: "تدريب", d: "M9 11l3 3 8-8M20 12v7a2 2 0 01-2 2H6a2 2 0 01-2-2V7a2 2 0 012-2h9" },
  { key: "progress", href: "/progress", label: "تقدّم", d: "M4 20V10M10 20V4M16 20v-8M22 20H2" },
  { key: "review", href: "/review", label: "مراجعة", d: "M4 4v6h6M20 20v-6h-6M20 10A8 8 0 006 6.3L4 10M4 14a8 8 0 0014 3.7L20 14" },
];

export default function Shell({
  active,
  children,
  hideNav,
  title,
  back,
}: {
  active?: string;
  children: ReactNode;
  hideNav?: boolean;
  title?: string;
  back?: string;
}) {
  return (
    <div className="min-h-dvh bg-[#ebe8e0]">
      <div className="relative mx-auto min-h-dvh w-full max-w-[430px] bg-paper pb-28 shadow-[0_0_0_1px_#e4e0d6]">
        {title && (
          <header className="sticky top-0 z-20 flex h-14 items-center gap-2 border-b border-line bg-paper/95 px-4 backdrop-blur">
            {back && (
              <Link
                href={back}
                aria-label="رجوع"
                className="-mr-2 flex h-11 w-11 items-center justify-center rounded-full text-ink"
              >
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M9 6l6 6-6 6" />
                </svg>
              </Link>
            )}
            <h1 className="text-[17px] font-bold">{title}</h1>
          </header>
        )}
        <main className="px-4 pt-4">{children}</main>
        {!hideNav && (
          <nav className="fixed inset-x-0 bottom-0 z-30 mx-auto flex w-full max-w-[430px] border-t border-line bg-white/95 pb-[env(safe-area-inset-bottom)] backdrop-blur">
            {ITEMS.map((it) => {
              const on = it.key === active;
              return (
                <Link
                  key={it.key}
                  href={it.href}
                  className={`flex min-h-[58px] flex-1 flex-col items-center justify-center gap-1 text-[11px] font-semibold ${on ? "text-brand" : "text-muted"}`}
                >
                  <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={on ? 2.3 : 1.8} strokeLinecap="round" strokeLinejoin="round">
                    <path d={it.d} />
                  </svg>
                  {it.label}
                  <span className={`h-[3px] w-5 rounded-full ${on ? "bg-brand" : "bg-transparent"}`} />
                </Link>
              );
            })}
          </nav>
        )}
      </div>
    </div>
  );
}

export function Loading({ text = "جارِ التحميل…" }: { text?: string }) {
  return (
    <div className="flex flex-col items-center gap-3 py-24 text-muted">
      <div className="h-8 w-8 animate-spin rounded-full border-[3px] border-line border-t-brand" />
      <p className="text-sm">{text}</p>
    </div>
  );
}
