"use client";
import { useEffect, useMemo, useState } from "react";
import { KIND_LABEL, isAr, type Question } from "@/lib/client";

const norm = (s: string) =>
  s
    .toLowerCase()
    .replace(/[^a-z0-9' ]/g, "")
    .replace(/\s+/g, " ")
    .trim();

/** عرض سؤال واحد من الأنواع الأربعة. reveal=true يظهر الصح والغلط بعد الإجابة */
export default function QuestionView({
  q,
  reveal,
  onAnswer,
}: {
  q: Question;
  reveal: boolean;
  onAnswer: (correct: boolean) => void;
}) {
  const [picked, setPicked] = useState<string | null>(null);
  const [used, setUsed] = useState<number[]>([]);
  const [done, setDone] = useState(false);
  const [ok, setOk] = useState(false);

  useEffect(() => {
    setPicked(null);
    setUsed([]);
    setDone(false);
    setOk(false);
  }, [q.id]);

  const chips = q.options;
  const built = useMemo(() => used.map((i) => chips[i]).join(" "), [used, chips]);

  const choose = (o: string) => {
    if (done) return;
    setPicked(o);
    setDone(true);
    const c = o === q.answer;
    setOk(c);
    onAnswer(c);
  };

  const check = () => {
    if (done || !used.length) return;
    const c = norm(built) === norm(q.answer);
    setDone(true);
    setOk(c);
    onAnswer(c);
  };

  const optClass = (o: string) => {
    const base =
      "w-full min-h-[48px] rounded-xl border px-4 py-2.5 text-[15px] font-medium transition-colors";
    if (!done) return `${base} border-line bg-white active:bg-brand-soft`;
    if (reveal) {
      if (o === q.answer) return `${base} border-brand bg-brand-soft text-brand`;
      if (o === picked) return `${base} border-bad bg-bad-soft text-bad`;
      return `${base} border-line bg-white opacity-60`;
    }
    return o === picked ? `${base} border-brand bg-brand-soft text-brand` : `${base} border-line bg-white opacity-60`;
  };

  const enOptions = q.kind === "cloze" || (q.kind === "mcq" && !isAr(q.options[0] ?? ""));

  return (
    <div className="card fade-up p-4">
      <span className="inline-block rounded-full bg-accent-soft px-3 py-1 text-[12px] font-semibold text-accent">
        {KIND_LABEL[q.kind]}
      </span>

      {q.kind === "mcq" && (
        <div className="mt-3">
          <p className={`text-[18px] font-semibold leading-8 ${isAr(q.prompt) ? "" : "ltr"}`}>{q.prompt}</p>
          {q.promptAr && <p className="mt-1 text-[13px] text-muted">{q.promptAr}</p>}
        </div>
      )}
      {q.kind === "cloze" && (
        <div className="mt-3">
          <p className="mb-2 text-[13px] text-muted">أكمل الجملة بالكلمة المناسبة:</p>
          <p className="ltr text-[19px] font-semibold leading-9">
            {q.prompt.split("_____").map((part, i, arr) => (
              <span key={i}>
                {part}
                {i < arr.length - 1 && (
                  <span
                    className={`mx-1 inline-block min-w-[70px] rounded-md border-b-2 px-2 text-center ${
                      done && reveal ? (ok ? "border-brand text-brand" : "border-bad text-bad") : "border-accent text-accent"
                    }`}
                  >
                    {done && (reveal || picked) ? picked : "؟"}
                  </span>
                )}
              </span>
            ))}
          </p>
          {q.promptAr && <p className="mt-2 text-[13px] text-muted">المعنى: {q.promptAr}</p>}
        </div>
      )}
      {q.kind === "translate" && (
        <div className="mt-3">
          <p className="mb-2 text-[13px] text-muted">ما معنى هذه الجملة؟</p>
          <p className="ltr text-[19px] font-semibold leading-8">{q.prompt}</p>
        </div>
      )}
      {q.kind === "order" && (
        <div className="mt-3">
          <p className="text-[13px] text-muted">{q.prompt}</p>
          {q.promptAr && <p className="mt-1 text-[16px] font-semibold leading-7">«{q.promptAr}»</p>}
          <div
            className={`ltr mt-3 flex min-h-[64px] flex-wrap items-center gap-2 rounded-xl border-2 border-dashed p-2 ${
              done && reveal ? (ok ? "border-brand bg-brand-soft" : "border-bad bg-bad-soft") : "border-line"
            }`}
          >
            {used.length === 0 && <span className="px-1 text-[13px] text-muted">اضغط الكلمات بالترتيب…</span>}
            {used.map((i, n) => (
              <button
                key={n}
                disabled={done}
                onClick={() => setUsed(used.filter((_, k) => k !== n))}
                className="min-h-[40px] rounded-lg border border-brand bg-white px-3 text-[15px] font-medium text-brand"
              >
                {chips[i]}
              </button>
            ))}
          </div>
          <div className="ltr mt-3 flex flex-wrap gap-2">
            {chips.map((c, i) => (
              <button
                key={i}
                disabled={done || used.includes(i)}
                onClick={() => setUsed([...used, i])}
                className="min-h-[40px] rounded-lg border border-line bg-white px-3 text-[15px] font-medium disabled:opacity-25"
              >
                {c}
              </button>
            ))}
          </div>
          {!done && (
            <div className="mt-4 flex gap-2">
              <button className="btn btn-primary flex-1" disabled={!used.length} onClick={check}>
                تحقّق
              </button>
              <button className="btn btn-ghost" disabled={!used.length} onClick={() => setUsed([])}>
                مسح
              </button>
            </div>
          )}
          {done && reveal && !ok && (
            <p className="ltr mt-3 rounded-lg bg-brand-soft p-2 text-[14px] font-medium text-brand">{q.answer}</p>
          )}
        </div>
      )}

      {q.kind !== "order" && (
        <div className={`mt-4 grid gap-2 ${q.kind === "cloze" || (q.kind === "mcq" && q.options.length === 2) ? "grid-cols-2" : "grid-cols-1"}`}>
          {q.options.map((o) => (
            <button key={o} onClick={() => choose(o)} disabled={done} className={`${optClass(o)} ${enOptions ? "ltr text-center" : "text-right"}`}>
              {o}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
