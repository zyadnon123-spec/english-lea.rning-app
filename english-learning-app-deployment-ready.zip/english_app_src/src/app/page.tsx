"use client";
import Link from "next/link";
import Shell, { Loading } from "@/components/Shell";
import { fmtDate, fmtMin, useAppState } from "@/lib/client";

export default function Home() {
  const { state, loading, error } = useAppState();

  if (loading) return <Shell active="home"><Loading /></Shell>;
  if (error || !state)
    return (
      <Shell active="home">
        <Loading text={error ? "تعذّر الاتصال… أعد المحاولة" : "جارِ التحويل لخطتك…"} />
      </Shell>
    );

  const { day, stats, review, notes } = state;
  const isExam = day.kind === "level_exam";
  const steps = isExam ? 1 : day.stories.length + 1;
  const doneSteps = isExam ? 0 : day.practiced;
  const later = day.scheduledDate > state.today;

  return (
    <Shell active="home">
      <div className="space-y-4 pb-2">
        <div className="flex items-start justify-between">
          <div>
            <p className="text-[13px] text-muted">{fmtDate(state.today)}</p>
            <h1 className="text-[28px] font-bold leading-10">اليوم {day.dayNo}</h1>
          </div>
          <div className="rounded-full border border-line bg-white px-3 py-1.5 text-[12px] font-bold text-brand">
            {day.level} · {day.levelName}
          </div>
        </div>

        <section className="rounded-3xl bg-brand p-5 text-white">
          <p className="text-[13px] opacity-80">{isExam ? "اختبار المستوى الشامل" : "درس اليوم"}</p>
          <div className="mt-1 flex items-end justify-between">
            <div>
              <p className="text-[34px] font-bold leading-[44px]">{fmtMin(day.plannedMin)}</p>
              <p className="text-[14px] opacity-90">
                {isExam
                  ? `20 سؤالًا من ${day.examStories} قصة في مستوى ${day.level}`
                  : `${day.stories.length} ${day.stories.length > 2 ? "قصص" : day.stories.length === 2 ? "قصتان" : "قصة"} من الفيديو`}
              </p>
            </div>
            {day.multiplier !== 1 && (
              <span className="rounded-full bg-white/20 px-3 py-1 text-[12px] font-bold">×{day.multiplier}</span>
            )}
          </div>

          <div className="mt-4">
            <div className="h-2.5 overflow-hidden rounded-full bg-white/25">
              <div className="h-full rounded-full bg-white transition-all" style={{ width: `${day.progress}%` }} />
            </div>
            <p className="mt-1.5 text-[12px] opacity-85">
              {isExam ? "اجتز الاختبار للانتقال للمستوى التالي" : `${doneSteps} من ${steps} خطوات (تدريب كل قصة + اختبار اليوم)`}
            </p>
          </div>

          {!isExam && (
            <ul className="ltr mt-3 space-y-1 text-[13px] opacity-95">
              {day.stories.map((s) => (
                <li key={s.id} className="flex items-center gap-2">
                  <span className={`inline-block h-4 w-4 rounded-full border text-center text-[10px] leading-[14px] ${s.practiced ? "border-white bg-white text-brand" : "border-white/60"}`}>
                    {s.practiced ? "✓" : ""}
                  </span>
                  <span className="truncate">{s.title}</span>
                  <span className="opacity-70">· {s.durMin}m</span>
                </li>
              ))}
            </ul>
          )}

          <Link
            href={isExam ? "/quiz" : "/lesson"}
            className="btn mt-4 w-full bg-white text-[16px] text-brand"
          >
            {isExam ? "ابدأ الاختبار الشامل" : "ابدأ درس اليوم"}
          </Link>
          {later && (
            <p className="mt-2 text-center text-[12px] opacity-85">
              موعده المجدول {fmtDate(day.scheduledDate)} — تقدر تبدأ الآن لو حابب.
            </p>
          )}
        </section>

        <section className="rounded-2xl border border-accent/40 bg-accent-soft p-4">
          <div className="flex items-start gap-2.5">
            <span className="mt-0.5 text-[18px]">🧭</span>
            <div className="space-y-1.5 text-[13px] leading-6 text-ink">
              {notes.slice(0, 2).map((n, i) => (
                <p key={i}>{n}</p>
              ))}
              <p className="text-[12px] text-muted">
                إجمالي أيام الخطة {state.totalDays} · أنجزت {state.doneDays} ·{" "}
                <Link href="/plan" className="font-semibold text-accent underline">
                  تعديل الخطة
                </Link>
              </p>
            </div>
          </div>
        </section>

        <section className="grid grid-cols-3 gap-2.5">
          <Stat value={String(stats.streak)} label="أيام متواصلة" />
          <Stat value={stats.avgQuiz >= 0 ? `${stats.avgQuiz}%` : "—"} label="متوسط الاختبارات" />
          <Stat value={stats.level} label={`المستوى · ${stats.levelDone}/${stats.levelTotal}`} accent />
        </section>

        <section className="card p-4">
          <div className="flex items-center justify-between">
            <h2 className="text-[16px] font-bold">مراجعة اليوم</h2>
            <span className="rounded-full bg-accent-soft px-3 py-1 text-[12px] font-bold text-accent">
              {review.due} بطاقة
            </span>
          </div>
          <p className="mt-1.5 text-[13px] leading-6 text-muted">
            {review.due > 0
              ? "كلمات وجمل من القصص التي درستها بتكرار متباعد."
              : "لا توجد بطاقات مستحقة الآن — تظهر هنا بعد تدريب القصص."}
            {review.weak > 0 && ` عندك ${review.weak} نقطة ضعف تنتظر المراجعة.`}
          </p>
          <Link href="/review" className="btn btn-ghost mt-3 w-full">
            {review.due > 0 ? "ابدأ المراجعة" : "افتح المراجعة"}
          </Link>
        </section>
      </div>
    </Shell>
  );
}

function Stat({ value, label, accent }: { value: string; label: string; accent?: boolean }) {
  return (
    <div className="card px-2 py-3 text-center">
      <p className={`text-[24px] font-bold leading-8 ${accent ? "text-accent" : "text-brand"}`}>{value}</p>
      <p className="mt-0.5 text-[11px] leading-4 text-muted">{label}</p>
    </div>
  );
}
