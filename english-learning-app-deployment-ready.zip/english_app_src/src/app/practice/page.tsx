"use client";
import { Suspense, useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { useSearchParams } from "next/navigation";
import Shell, { Loading } from "@/components/Shell";
import QuestionView from "@/components/QuestionView";
import YTPlayer from "@/components/YTPlayer";
import { api, fmtSec, post, useAppState, type Question } from "@/lib/client";

export default function PracticePage() {
  return (
    <Suspense fallback={<Shell active="practice"><Loading /></Shell>}>
      <Practice />
    </Suspense>
  );
}

type Res = { pct: number; score: number; total: number };

function Practice() {
  const sp = useSearchParams();
  const { state, loading } = useAppState();
  const [sel, setSel] = useState<number | null>(null);
  const [round, setRound] = useState(0);
  const [qs, setQs] = useState<Question[] | null>(null);
  const [i, setI] = useState(0);
  const [ans, setAns] = useState<boolean | null>(null);
  const [results, setResults] = useState<boolean[]>([]);
  const [showVideo, setShowVideo] = useState(false);
  const [final, setFinal] = useState<Res | null>(null);
  const [weakMode, setWeakMode] = useState(sp.get("mode") === "weak");

  const day = state?.day;
  const paramId = Number(sp.get("story")) || 0;
  const stories = day?.kind === "study" ? day.stories : [];
  const defId = paramId || stories.find((s) => !s.practiced)?.id || stories[0]?.id || 0;
  const storyId = sel ?? defId;
  const effWeak = weakMode || (!!day && day.kind === "level_exam" && !paramId && sel === null);

  const url = !state
    ? null
    : effWeak
      ? "/api/questions?mode=weak"
      : storyId
        ? `/api/questions?mode=practice&story=${storyId}`
        : null;

  useEffect(() => {
    if (!url) return;
    let dead = false;
    setQs(null);
    setI(0);
    setAns(null);
    setResults([]);
    setFinal(null);
    setShowVideo(false);
    api<{ questions: Question[] }>(url).then((d) => !dead && setQs(d.questions));
    return () => {
      dead = true;
    };
  }, [url, round]);

  const onAnswer = useCallback(
    (correct: boolean) => {
      if (!qs) return;
      setAns(correct);
      setResults((r) => [...r, correct]);
      post("/api/answer", { id: qs[i].id, correct }).catch(() => {});
    },
    [qs, i],
  );

  const next = async () => {
    if (!qs) return;
    if (i + 1 < qs.length) {
      setI(i + 1);
      setAns(null);
      setShowVideo(false);
      return;
    }
    const score = results.filter(Boolean).length;
    if (!effWeak && storyId) {
      const r = await post<Res>("/api/attempt", {
        kind: "practice",
        storyId,
        results: qs.map((q, k) => ({ id: q.id, correct: results[k] })),
      });
      setFinal(r);
    } else {
      setFinal({ score, total: qs.length, pct: Math.round((score / qs.length) * 100) });
    }
  };

  if (loading || !state || !day) return <Shell active="practice"><Loading /></Shell>;
  const q = qs?.[i];
  const cur = stories.find((s) => s.id === storyId);

  return (
    <Shell active="practice">
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h1 className="text-[20px] font-bold">{effWeak ? "تدريب نقاط الضعف" : "تدريب القصة"}</h1>
          {!effWeak && (
            <button
              onClick={() => {
                setWeakMode(true);
                setSel(null);
              }}
              className="min-h-[44px] text-[12px] font-bold text-accent underline"
            >
              تدريب نقاط الضعف
            </button>
          )}
          {effWeak && stories.length > 0 && (
            <button
              onClick={() => {
                setWeakMode(false);
                setSel(storyId);
              }}
              className="min-h-[44px] text-[12px] font-bold text-brand underline"
            >
              العودة لتدريب القصة
            </button>
          )}
        </div>

        {!effWeak && stories.length > 1 && (
          <div className="scrollx -mx-4 flex gap-2 px-4">
            {stories.map((s) => (
              <button
                key={s.id}
                onClick={() => {
                  setSel(s.id);
                  setRound((r) => r + 1);
                }}
                className={`min-h-[44px] shrink-0 rounded-full border px-4 text-[13px] font-semibold ${
                  s.id === storyId ? "border-brand bg-brand text-white" : "border-line bg-white"
                }`}
              >
                قصة {s.idx} {s.practiced ? "✓" : ""}
              </button>
            ))}
          </div>
        )}
        {!effWeak && cur && <p className="ltr -mt-1 text-[13px] text-muted">{cur.title}</p>}

        {!qs && url && <Loading text="نجهّز أسئلة من القصة…" />}
        {!url && (
          <div className="card p-5 text-center text-sm text-muted">
            اختر قصة من «الدرس» أولًا، أو{" "}
            <button className="font-bold text-accent underline" onClick={() => setWeakMode(true)}>
              تدرّب على نقاط الضعف
            </button>
            .
          </div>
        )}
        {qs && qs.length === 0 && (
          <div className="card p-5 text-center text-sm text-muted">
            لا توجد نقاط ضعف مسجّلة بعد — ابدأ بتدريب قصة وسنجمع أخطاءك هنا.
          </div>
        )}

        {qs && qs.length > 0 && !final && q && (
          <>
            <div>
              <div className="mb-1.5 flex items-center justify-between text-[12px] text-muted">
                <span>
                  سؤال {i + 1} من {qs.length}
                </span>
                <span>{results.filter(Boolean).length} صحيحة</span>
              </div>
              <div className="flex gap-1">
                {qs.map((_, k) => (
                  <span
                    key={k}
                    className={`h-2 flex-1 rounded-full ${
                      k < results.length ? (results[k] ? "bg-brand" : "bg-bad") : k === i ? "bg-accent" : "bg-line"
                    }`}
                  />
                ))}
              </div>
            </div>

            <QuestionView key={q.id} q={q} reveal onAnswer={onAnswer} />

            {ans !== null && (
              <div className={`fade-up rounded-2xl border p-4 ${ans ? "border-brand/40 bg-brand-soft" : "border-bad/40 bg-bad-soft"}`}>
                <p className={`text-[15px] font-bold ${ans ? "text-brand" : "text-bad"}`}>
                  {ans ? "✓ إجابة صحيحة" : "✗ إجابة غير صحيحة"}
                </p>
                <p className="mt-1.5 text-[14px] leading-7">{q.explanation}</p>
                <button
                  className="btn btn-ghost mt-3 w-full"
                  onClick={() => setShowVideo((v) => !v)}
                >
                  {showVideo ? "إخفاء الفيديو" : `↩ ارجع للفيديو عند ${fmtSec(q.seekSec)}`}
                </button>
                {showVideo && (
                  <div className="mt-3">
                    <YTPlayer key={q.id} start={Math.max(0, q.seekSec - 2)} end={q.seekSec + 75} autoplay />
                  </div>
                )}
                <button className="btn btn-primary mt-3 w-full" onClick={next}>
                  {i + 1 < qs.length ? "السؤال التالي" : "إنهاء التدريب"}
                </button>
              </div>
            )}
          </>
        )}

        {final && qs && (
          <div className="card fade-up space-y-3 p-5 text-center">
            <p className="text-[13px] text-muted">نتيجة التدريب</p>
            <p className={`text-[44px] font-bold leading-[52px] ${final.pct >= 70 ? "text-brand" : "text-accent"}`}>
              {final.score}/{final.total}
            </p>
            <p className="text-[14px] leading-7">
              {final.pct >= 90
                ? "ممتاز! القصة ثبتت."
                : final.pct >= 70
                  ? "جيد جدًا. راجع الأخطاء في بطاقات المراجعة."
                  : "تحتاج مراجعة بسيطة للقصة — أعد المشاهدة ثم حاول مرة أخرى."}
            </p>
            {!effWeak && <p className="text-[12px] text-muted">أضفنا مفردات القصة وجملها لبطاقات المراجعة (تظهر غدًا).</p>}
            <div className="grid gap-2">
              <Link href="/quiz" className="btn btn-accent">
                اختبار اليوم
              </Link>
              <button className="btn btn-primary" onClick={() => setRound((r) => r + 1)}>
                تدريب جديد بأسئلة مختلفة
              </button>
              <Link href="/" className="btn btn-ghost">
                الرئيسية
              </Link>
            </div>
          </div>
        )}
      </div>
    </Shell>
  );
}
