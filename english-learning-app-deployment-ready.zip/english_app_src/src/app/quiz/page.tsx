"use client";
import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import Shell, { Loading } from "@/components/Shell";
import QuestionView from "@/components/QuestionView";
import { api, fmtDate, fmtMin, fmtSec, post, useAppState, ytLink, type Question } from "@/lib/client";

type QuizData = {
  dayId: number;
  dayNo: number;
  kind: "study" | "level_exam";
  level: string;
  retake: boolean;
  questions: Question[];
  stories: { id: number; title: string; idx: number }[];
};
type Final = {
  pct: number;
  score: number;
  total: number;
  passed: boolean;
  multiplier: number;
  next: { dayNo: number; plannedMin: number; multiplier: number; scheduledDate: string; kind: string } | null;
  kind: string;
};

export default function QuizPage() {
  const { state, loading } = useAppState();
  const [data, setData] = useState<QuizData | null>(null);
  const [round, setRound] = useState(0);
  const [started, setStarted] = useState(false);
  const [i, setI] = useState(0);
  const [results, setResults] = useState<boolean[]>([]);
  const [answered, setAnswered] = useState(false);
  const [final, setFinal] = useState<Final | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!state) return;
    let dead = false;
    setData(null);
    setStarted(false);
    setI(0);
    setResults([]);
    setAnswered(false);
    setFinal(null);
    api<QuizData>("/api/questions?mode=quiz").then((d) => !dead && setData(d));
    return () => {
      dead = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [!!state, round]);

  const onAnswer = useCallback(
    (correct: boolean) => {
      if (!data) return;
      setAnswered(true);
      setResults((r) => [...r, correct]);
      post("/api/answer", { id: data.questions[i].id, correct }).catch(() => {});
    },
    [data, i],
  );

  const next = async () => {
    if (!data) return;
    if (i + 1 < data.questions.length) {
      setI(i + 1);
      setAnswered(false);
      return;
    }
    setBusy(true);
    const f = await post<Final>("/api/attempt", {
      kind: "quiz",
      dayId: data.dayId,
      results: data.questions.map((q, k) => ({ id: q.id, correct: results[k] })),
    });
    setFinal(f);
    setBusy(false);
  };

  if (loading || !state) return <Shell active="lesson" hideNav><Loading /></Shell>;
  const exam = data?.kind === "level_exam";
  const n = data?.questions.length ?? 0;

  return (
    <Shell hideNav title={exam ? "الاختبار الشامل" : "اختبار اليوم"} back="/lesson">
      {!data ? (
        <Loading text="نجهّز الاختبار من قصص اليوم…" />
      ) : !started ? (
        <div className="space-y-4">
          <div className="card space-y-3 p-5">
            <h2 className="text-[20px] font-bold">
              {exam ? `اختبار مستوى ${data.level} الشامل` : `اختبار اليوم ${data.dayNo}`}
            </h2>
            <p className="text-[14px] leading-7 text-muted">
              {n} سؤالًا من {exam ? `قصص مستوى ${data.level}` : "قصص اليوم فقط"}. لا تظهر الإجابات الصحيحة إلا في النهاية. شرط النجاح{" "}
              <b className="text-ink">70%</b>
              {exam ? " للانتقال للمستوى التالي." : "."}
            </p>
            {data.retake && (
              <p className="rounded-xl bg-accent-soft p-3 text-[13px] leading-6 text-accent">
                هذه إعادة للاختبار — أدخلنا فيه أجزاء الغلط من المحاولة السابقة ونقاط ضعفك.
              </p>
            )}
            {!exam && (
              <ul className="ltr space-y-1 text-[13px] text-ink/80">
                {data.stories.map((s) => (
                  <li key={s.id}>• {s.title}</li>
                ))}
              </ul>
            )}
          </div>
          <button className="btn btn-primary w-full text-[16px]" disabled={n === 0} onClick={() => setStarted(true)}>
            ابدأ الاختبار
          </button>
        </div>
      ) : !final ? (
        <div className="space-y-4">
          <div>
            <div className="mb-1.5 flex justify-between text-[12px] text-muted">
              <span>
                سؤال {i + 1} من {n}
              </span>
              <span>{answered ? "تم" : "اختر إجابتك"}</span>
            </div>
            <div className="flex gap-[3px]">
              {data.questions.map((_, k) => (
                <span
                  key={k}
                  className={`h-2 flex-1 rounded-full ${k < results.length ? "bg-brand" : k === i ? "bg-accent" : "bg-line"}`}
                />
              ))}
            </div>
          </div>
          <QuestionView key={data.questions[i].id} q={data.questions[i]} reveal={false} onAnswer={onAnswer} />
          {answered && (
            <button className="btn btn-primary fade-up w-full" disabled={busy} onClick={next}>
              {i + 1 < n ? "التالي" : "إنهاء وعرض النتيجة"}
            </button>
          )}
        </div>
      ) : (
        <div className="space-y-4 pb-6">
          <div className="card space-y-3 p-5 text-center">
            <p className="text-[13px] text-muted">درجتك</p>
            <div
              className={`mx-auto flex h-32 w-32 flex-col items-center justify-center rounded-full border-[8px] ${
                final.passed ? "border-brand text-brand" : "border-accent text-accent"
              }`}
            >
              <span className="text-[34px] font-bold leading-9">{final.pct}%</span>
              <span className="text-[12px]">
                {final.score}/{final.total}
              </span>
            </div>
            <p className="text-[17px] font-bold">{final.passed ? "نجحت 🎉" : "لم تصل لحد النجاح (70%)"}</p>
            <p className="text-[13px] leading-7 text-muted">
              {final.passed
                ? final.kind === "level_exam"
                  ? final.next
                    ? "اجتزت الاختبار الشامل وانفتح المستوى التالي."
                    : "أنهيت كل المستويات. مبروك على الـ100 ساعة!"
                  : final.multiplier > 1
                    ? "أداء ممتاز — اليوم القادم أطول قليلًا (×1.25)."
                    : final.multiplier < 1
                      ? "نجحت بعد إعادة — اليوم القادم أخف (×0.75) مع مراجعة لأجزاء الغلط."
                      : "اليوم القادم بنفس الطول."
                : "اليوم القادم سيكون أخف (×0.75) مع مراجعة لأجزاء الغلط. راجع الأخطاء أدناه ثم أعد الاختبار."}
            </p>
            {final.passed && final.next && (
              <p className="rounded-xl bg-brand-soft p-3 text-[13px] text-brand">
                {final.next.kind === "level_exam" ? "التالي: الاختبار الشامل" : `التالي: اليوم ${final.next.dayNo} — ${fmtMin(final.next.plannedMin)}`}{" "}
                · {fmtDate(final.next.scheduledDate)}
              </p>
            )}
          </div>

          {data.questions.some((_, k) => !results[k]) && (
            <section className="space-y-2.5">
              <h3 className="text-[15px] font-bold">أجزاء الغلط</h3>
              {data.questions.map((q, k) =>
                results[k] ? null : (
                  <div key={q.id} className="card p-3.5">
                    <p className={`text-[14px] font-semibold leading-6 ${q.kind === "mcq" && q.sub === "vocab" ? "" : "ltr"}`}>
                      {q.kind === "order" ? q.promptAr : q.prompt}
                    </p>
                    <p className="ltr mt-1 text-[13px] font-bold text-brand">{q.answer}</p>
                    <p className="mt-1 text-[12px] leading-6 text-muted">{q.explanation}</p>
                    <a href={ytLink(q.seekSec)} target="_blank" rel="noreferrer" className="mt-1 inline-block text-[12px] font-bold text-accent underline">
                      ▶ الفيديو عند {fmtSec(q.seekSec)}
                    </a>
                  </div>
                ),
              )}
            </section>
          )}

          <div className="grid gap-2">
            {!final.passed && (
              <>
                <button className="btn btn-primary" onClick={() => setRound((r) => r + 1)}>
                  أعد الاختبار
                </button>
                <Link href="/lesson" className="btn btn-ghost">
                  راجع الدرس
                </Link>
                <Link href="/review" className="btn btn-ghost">
                  راجع أجزاء الغلط (بطاقات)
                </Link>
              </>
            )}
            <Link href="/" className={`btn ${final.passed ? "btn-primary" : "btn-ghost"}`}>
              الرئيسية
            </Link>
          </div>
        </div>
      )}
    </Shell>
  );
}
