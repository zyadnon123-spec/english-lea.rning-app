"use client";
import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import Shell, { Loading } from "@/components/Shell";
import { api, fmtSec, post, ytLink } from "@/lib/client";

type Card = {
  id: number;
  kind: "word" | "sentence";
  front: string;
  back: string;
  example: string;
  storyId: number;
  sourceSec: number;
  title: string;
  idx: number;
  level: string;
};
type Data = { cards: Card[]; dueTotal: number; tomorrow: number; totalCards: number };

const RATES = [
  { k: "hard", label: "صعبة", sub: "غدًا", cls: "border-bad/50 bg-bad-soft text-bad" },
  { k: "ok", label: "تمام", sub: "بعد 3 أيام", cls: "border-accent/50 bg-accent-soft text-accent" },
  { k: "easy", label: "سهلة", sub: "بعد أسبوع", cls: "border-brand/50 bg-brand-soft text-brand" },
] as const;

export default function ReviewPage() {
  const [data, setData] = useState<Data | null>(null);
  const [filter, setFilter] = useState<"all" | "word" | "sentence">("all");
  const [i, setI] = useState(0);
  const [flip, setFlip] = useState(false);
  const [done, setDone] = useState(0);
  const [queue, setQueue] = useState<Card[]>([]);

  useEffect(() => {
    api<Data>("/api/review").then((d) => {
      setData(d);
      setQueue(d.cards);
    });
  }, []);

  const list = useMemo(() => queue.filter((c) => filter === "all" || c.kind === filter), [queue, filter]);
  const card = list[0];
  void i;

  const rate = async (k: "hard" | "ok" | "easy") => {
    if (!card) return;
    const c = card;
    setQueue((q) => q.filter((x) => x.id !== c.id));
    setFlip(false);
    setDone((d) => d + 1);
    setI((x) => x + 1);
    await post("/api/review", { id: c.id, rating: k }).catch(() => {});
  };

  return (
    <Shell active="review">
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h1 className="text-[20px] font-bold">المراجعة</h1>
          {data && (
            <span className="rounded-full bg-accent-soft px-3 py-1 text-[12px] font-bold text-accent">
              متبقّي {Math.max(data.dueTotal - done, 0)}
            </span>
          )}
        </div>

        <div className="grid grid-cols-3 gap-1 rounded-2xl border border-line bg-white p-1">
          {(
            [
              ["all", "الكل"],
              ["word", "كلمات"],
              ["sentence", "جمل"],
            ] as const
          ).map(([k, n]) => (
            <button
              key={k}
              onClick={() => setFilter(k)}
              className={`min-h-[44px] rounded-xl text-[14px] font-semibold ${filter === k ? "bg-brand text-white" : "text-muted"}`}
            >
              {n}
            </button>
          ))}
        </div>

        {!data ? (
          <Loading />
        ) : card ? (
          <div className="space-y-3">
            <div className="card fade-up flex min-h-[260px] flex-col items-center justify-center p-6 text-center" key={card.id}>
              <span className="mb-3 rounded-full bg-brand-soft px-3 py-1 text-[12px] font-bold text-brand">
                {card.kind === "word" ? "كلمة" : "جملة"}
              </span>
              <p className={`ltr text-center font-bold leading-10 ${card.kind === "word" ? "text-[32px]" : "text-[21px] leading-9"}`}>
                {card.front}
              </p>
              {flip ? (
                <div className="mt-4 space-y-2">
                  <p className="text-[22px] font-semibold text-accent">{card.back}</p>
                  {card.example && <p className="ltr text-[13px] text-muted">“{card.example}”</p>}
                </div>
              ) : (
                <button className="btn btn-primary mt-6" onClick={() => setFlip(true)}>
                  اقلب البطاقة
                </button>
              )}
              <a
                href={ytLink(card.sourceSec)}
                target="_blank"
                rel="noreferrer"
                className="mt-5 text-[12px] text-muted underline"
              >
                المصدر: قصة {card.idx} · {card.level} · {fmtSec(card.sourceSec)}
              </a>
            </div>

            {flip ? (
              <div className="grid grid-cols-3 gap-2 fade-up">
                {RATES.map((r) => (
                  <button key={r.k} onClick={() => rate(r.k)} className={`min-h-[60px] rounded-xl border px-2 py-2 ${r.cls}`}>
                    <div className="text-[15px] font-bold">{r.label}</div>
                    <div className="text-[11px] opacity-85">{r.sub}</div>
                  </button>
                ))}
              </div>
            ) : (
              <p className="text-center text-[12px] text-muted">فكّر في المعنى أولًا ثم اقلب البطاقة وقيّم نفسك.</p>
            )}
          </div>
        ) : (
          <div className="card space-y-3 p-6 text-center">
            <p className="text-[40px]">🎉</p>
            <p className="text-[17px] font-bold">
              {data.totalCards === 0 ? "لا توجد بطاقات بعد" : "خلّصت مراجعة اليوم"}
            </p>
            <p className="text-[13px] leading-7 text-muted">
              {data.totalCards === 0
                ? "تُضاف بطاقات الكلمات والجمل تلقائيًا بعد تدريب كل قصة، وأي إجابة غلط تدخل هنا."
                : `بطاقات غدًا: ${data.tomorrow + done} تقريبًا. القاعدة: صعبة = غدًا · تمام = 3 أيام · سهلة = أسبوع.`}
            </p>
            <div className="grid gap-2">
              <Link href="/lesson" className="btn btn-primary">
                إلى الدرس
              </Link>
              <Link href="/progress" className="btn btn-ghost">
                نقاط الضعف
              </Link>
            </div>
          </div>
        )}
      </div>
    </Shell>
  );
}
