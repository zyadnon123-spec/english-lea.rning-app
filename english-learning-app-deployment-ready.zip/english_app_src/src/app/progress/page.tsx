"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import Shell, { Loading } from "@/components/Shell";
import { fmtDate, fmtSec, post, useApi, ytLink } from "@/lib/client";

type Weak = {
  id: number;
  kind: string;
  key: string;
  label: string;
  labelAr: string;
  storyId: number;
  sec: number;
  attempts: number;
  wrong: number;
  rate: number;
};
type Data =
  | { started: false }
  | {
      started: true;
      calendar: { dayNo: number; state: "done" | "today" | "next"; date: string; kind: string; level: string; score: number | null }[];
      scores: { id: number; pct: number; dayNo: number; kind: string }[];
      weakWords: Weak[];
      weakGrammar: Weak[];
      totalDays: number;
      doneDays: number;
      missed: number;
      streak: number;
      finishDate?: string;
    };

export default function ProgressPage() {
  const router = useRouter();
  const { data } = useApi<Data>("/api/progress");
  const [all, setAll] = useState(false);
  const [busy, setBusy] = useState(false);

  if (!data) return <Shell active="progress"><Loading /></Shell>;
  if (!data.started) {
    return (
      <Shell active="progress">
        <div className="card mt-6 p-6 text-center">
          <p className="mb-3 text-sm text-muted">ابدأ خطتك أولًا لتظهر متابعتك هنا.</p>
          <button className="btn btn-primary" onClick={() => router.push("/plan")}>
            إعداد الخطة
          </button>
        </div>
      </Shell>
    );
  }

  const cur = data.calendar.find((c) => c.state === "today")?.dayNo ?? data.doneDays + 1;
  const from = all ? 1 : Math.max(1, cur - 7);
  const days = data.calendar.filter((d) => d.dayNo >= from && (all || d.dayNo < from + 35));
  const hasWeak = data.weakWords.length + data.weakGrammar.length > 0;

  const review = async () => {
    setBusy(true);
    await post("/api/review/weak", {});
    router.push("/review");
  };

  return (
    <Shell active="progress">
      <div className="space-y-5 pb-2">
        <h1 className="text-[20px] font-bold">المتابعة</h1>

        <div className="grid grid-cols-3 gap-2.5">
          <Mini v={`${data.doneDays}/${data.totalDays}`} l="أيام منجزة" />
          <Mini v={String(data.streak)} l="أيام متواصلة" />
          <Mini v={String(data.missed)} l="أيام فائتة" warn={data.missed > 0} />
        </div>

        <section className="card p-4">
          <div className="mb-3 flex items-center justify-between">
            <h2 className="text-[15px] font-bold">تقويم الأيام</h2>
            <button onClick={() => setAll((v) => !v)} className="min-h-[36px] text-[12px] font-bold text-brand underline">
              {all ? "عرض القريب" : "عرض كل الأيام"}
            </button>
          </div>
          <div className="grid grid-cols-7 gap-1.5">
            {days.map((d) => {
              const exam = d.kind === "level_exam";
              const base =
                d.state === "done"
                  ? "bg-brand text-white border-brand"
                  : d.state === "today"
                    ? "bg-accent text-white border-accent"
                    : "bg-white text-ink border-line";
              return (
                <div
                  key={d.dayNo}
                  title={`${fmtDate(d.date)}${exam ? " — اختبار شامل" : ""}`}
                  className={`relative flex h-11 items-center justify-center rounded-lg border text-[13px] font-bold ${base}`}
                >
                  {d.state === "done" && !exam ? "✓" : d.dayNo}
                  {exam && <span className="absolute -top-1 -left-1 text-[10px]">⭐</span>}
                </div>
              );
            })}
          </div>
          <div className="mt-3 flex flex-wrap gap-x-4 gap-y-1 text-[11px] text-muted">
            <Legend c="bg-brand" t="مكتمل" />
            <Legend c="bg-accent" t="اليوم" />
            <Legend c="border border-line bg-white" t="القادم" />
            <span>⭐ اختبار شامل</span>
          </div>
          {data.finishDate && (
            <p className="mt-2 text-[12px] text-muted">
              تنتهي الخطة تقريبًا في {fmtDate(data.finishDate)} (تتجدد مع أدائك وأيام غيابك).
            </p>
          )}
        </section>

        <section className="card p-4">
          <h2 className="mb-3 text-[15px] font-bold">نتائج الاختبارات</h2>
          {data.scores.length === 0 ? (
            <p className="py-6 text-center text-[13px] text-muted">لا توجد اختبارات بعد.</p>
          ) : (
            <div className="relative h-40">
              <div className="absolute inset-x-0 border-t border-dashed border-accent/60" style={{ bottom: "70%" }}>
                <span className="absolute -top-4 left-0 text-[10px] font-bold text-accent">70%</span>
              </div>
              <div className="absolute inset-0 flex items-end gap-2 pt-4">
                {data.scores.map((s) => (
                  <div key={s.id} className="flex h-full flex-1 flex-col items-center justify-end">
                    <span className="mb-1 text-[10px] font-bold text-muted">{s.pct}</span>
                    <div
                      className={`w-full max-w-[28px] rounded-t-md ${s.pct >= 70 ? "bg-brand" : "bg-accent"}`}
                      style={{ height: `${Math.max(s.pct * 0.78, 3)}%` }}
                    />
                    <span className="mt-1 text-[10px] text-muted">{s.kind === "level" ? "⭐" : `ي${s.dayNo}`}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </section>

        <section className="card p-4">
          <h2 className="mb-3 text-[15px] font-bold">نقاط الضعف</h2>
          {!hasWeak ? (
            <p className="py-4 text-center text-[13px] text-muted">
              لا توجد أخطاء مسجّلة بعد. كل إجابة غلط في التدريب أو الاختبار تظهر هنا بنسبة الغلط.
            </p>
          ) : (
            <div className="space-y-4">
              {data.weakGrammar.length > 0 && <WeakGroup title="قواعد" items={data.weakGrammar} />}
              {data.weakWords.length > 0 && <WeakGroup title="كلمات" items={data.weakWords} />}
              <button className="btn btn-accent w-full" disabled={busy} onClick={review}>
                راجعهم
              </button>
            </div>
          )}
        </section>
      </div>
    </Shell>
  );
}

function Mini({ v, l, warn }: { v: string; l: string; warn?: boolean }) {
  return (
    <div className="card px-2 py-3 text-center">
      <p className={`text-[22px] font-bold leading-8 ${warn ? "text-accent" : "text-brand"}`}>{v}</p>
      <p className="text-[11px] text-muted">{l}</p>
    </div>
  );
}
function Legend({ c, t }: { c: string; t: string }) {
  return (
    <span className="flex items-center gap-1.5">
      <i className={`inline-block h-3 w-3 rounded ${c}`} />
      {t}
    </span>
  );
}
function WeakGroup({ title, items }: { title: string; items: Weak[] }) {
  return (
    <div>
      <p className="mb-2 text-[12px] font-bold text-muted">{title}</p>
      <div className="space-y-2.5">
        {items.slice(0, 6).map((w) => (
          <div key={w.id}>
            <div className="mb-1 flex items-center justify-between gap-2 text-[13px]">
              <span className="ltr truncate font-semibold">
                {w.label} {w.labelAr && <span className="text-muted">· {w.labelAr}</span>}
              </span>
              <a href={ytLink(w.sec)} target="_blank" rel="noreferrer" className="shrink-0 text-[11px] text-muted underline">
                {fmtSec(w.sec)}
              </a>
              <span className={`shrink-0 font-bold ${w.rate >= 50 ? "text-bad" : "text-accent"}`}>{w.rate}% غلط</span>
            </div>
            <div className="h-2 overflow-hidden rounded-full bg-line">
              <div className={`h-full rounded-full ${w.rate >= 50 ? "bg-bad" : "bg-accent"}`} style={{ width: `${w.rate}%` }} />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
