import { db } from "@/db";
import * as S from "@/db/schema";
import {
  getLite,
  getSettings,
  buildFuture,
  baseMinutes,
  assignDates,
  roughEstimate,
  loadPlan,
  today,
  eq,
  inArray,
  sql,
} from "@/lib/engine";

export const dynamic = "force-dynamic";

function parseRest(v: string | null) {
  return (v ?? "")
    .split(",")
    .filter((x) => x !== "")
    .map(Number)
    .filter((n) => n >= 0 && n <= 6);
}

export async function GET(req: Request) {
  const sp = new URL(req.url).searchParams;
  const settings = await getSettings();
  const minutes = sp.has("minutes") ? Number(sp.get("minutes")) : settings.minutesPerDay;
  const rest = sp.has("rest") ? parseRest(sp.get("rest")) : (settings.restDays as number[]);
  const all = await getLite();
  const base = baseMinutes(minutes);
  const fut = buildFuture(all, new Set(), new Set(), base, 1);
  const dates = assignDates(fut.length, today(), rest);
  const days = fut.map((f, i) => ({ ...f, dayNo: i + 1, date: dates[i] }));
  return Response.json({
    started: settings.started,
    minutes,
    rest,
    roughTotal: roughEstimate(base),
    totalDays: days.length,
    finishDate: days[days.length - 1]?.date,
    analyzed: all.length,
    preview: days.slice(0, 3).map((d) => ({
      dayNo: d.dayNo,
      date: d.date,
      level: d.level,
      kind: d.kind,
      plannedMin: d.plannedMin,
      stories: d.storyIds.length,
      titles: d.storyIds.map((id) => all.find((s) => s.id === id)?.title ?? ""),
    })),
  });
}

export async function POST(req: Request) {
  const body = (await req.json()) as { minutes: number; rest: number[] };
  const minutes = [0, 60, 120, 180].includes(body.minutes) ? body.minutes : 60;
  const rest = (body.rest ?? []).filter((n) => n >= 0 && n <= 6);
  const cur = await getSettings();
  await db
    .update(S.settings)
    .set({
      minutesPerDay: minutes,
      restDays: rest,
      started: true,
      startDate: cur.startDate ?? today(),
    })
    .where(eq(S.settings.id, 1));
  // لو اليوم النشط لسه ما بدأ نعيد توليده بالإعدادات الجديدة
  const [act] = await db.select().from(S.planDays).where(eq(S.planDays.status, "active"));
  if (act) {
    const ids = act.storyIds as number[];
    const [a] = await db
      .select({ c: sql<number>`count(*)::int` })
      .from(S.attempts)
      .where(eq(S.attempts.dayId, act.id));
    const pr = await db
      .select({ c: sql<number>`count(*)::int` })
      .from(S.storyProgress)
      .where(inArray(S.storyProgress.storyId, ids));
    if (a.c === 0 && pr[0].c === 0) {
      await db.delete(S.planDays).where(eq(S.planDays.id, act.id));
    }
  }
  await loadPlan();
  return Response.json({ ok: true });
}
