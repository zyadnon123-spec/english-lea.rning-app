import { db } from "@/db";
import * as S from "@/db/schema";
import {
  PASS,
  addDays,
  today,
  loadPlan,
  ensureStoryCards,
  touchActivity,
  getLite,
  eq,
  sql,
} from "@/lib/engine";

export const dynamic = "force-dynamic";

type Body = {
  kind: "practice" | "quiz";
  storyId?: number;
  dayId?: number;
  results: { id: number; correct: boolean }[];
};

export async function POST(req: Request) {
  const b = (await req.json()) as Body;
  await getLite();
  const total = b.results.length;
  const score = b.results.filter((r) => r.correct).length;
  const pct = total ? Math.round((score / total) * 100) : 0;
  const wrongIds = b.results.filter((r) => !r.correct).map((r) => r.id);
  const t = today();
  const tomorrow = addDays(t, 1);
  await touchActivity();

  if (b.kind === "practice" && b.storyId) {
    const p = await loadPlan();
    const dayId =
      p.active && (p.active.storyIds as number[]).includes(b.storyId) ? p.active.id : null;
    await db.insert(S.attempts).values({
      dayId,
      kind: "practice",
      storyId: b.storyId,
      score,
      total,
      pct,
      wrongIds,
      date: t,
    });
    await db
      .insert(S.storyProgress)
      .values({ storyId: b.storyId, bestScore: pct })
      .onConflictDoUpdate({
        target: S.storyProgress.storyId,
        set: {
          practicedAt: new Date(),
          bestScore: sql`greatest(${S.storyProgress.bestScore}, ${pct})`,
        },
      });
    await ensureStoryCards(b.storyId, tomorrow);
    return Response.json({ pct, score, total });
  }

  // اختبار اليوم / الاختبار الشامل
  const [day] = await db.select().from(S.planDays).where(eq(S.planDays.id, b.dayId ?? -1));
  if (!day) return Response.json({ error: "no day" }, { status: 400 });
  await db.insert(S.attempts).values({
    dayId: day.id,
    kind: day.kind === "level_exam" ? "level" : "quiz",
    score,
    total,
    pct,
    wrongIds,
    date: t,
  });
  const passed = pct >= PASS;
  let multiplier = 1;
  let next: { dayNo: number; plannedMin: number; multiplier: number; scheduledDate: string; kind: string } | null = null;
  if (day.status === "active") {
    const first = day.attempts === 0;
    await db
      .update(S.planDays)
      .set({
        attempts: day.attempts + 1,
        firstScore: day.firstScore ?? pct,
        bestScore: Math.max(day.bestScore ?? 0, pct),
        ...(passed ? { status: "done", completedDate: t } : {}),
      })
      .where(eq(S.planDays.id, day.id));
    if (first) {
      multiplier = pct < PASS ? 0.75 : pct > 90 ? 1.25 : 1;
      await db.update(S.settings).set({ nextMultiplier: multiplier }).where(eq(S.settings.id, 1));
    } else {
      const [s] = await db.select().from(S.settings).where(eq(S.settings.id, 1));
      multiplier = s.nextMultiplier;
    }
    if (passed) {
      if (day.kind === "study") {
        for (const sid of day.storyIds as number[]) await ensureStoryCards(sid, tomorrow);
      }
      const p = await loadPlan();
      if (p.active)
        next = {
          dayNo: p.active.dayNo,
          plannedMin: p.active.plannedMin,
          multiplier: p.active.multiplier,
          scheduledDate: p.active.scheduledDate,
          kind: p.active.kind,
        };
    }
  }
  return Response.json({ pct, score, total, passed, multiplier, next, kind: day.kind });
}
