import { db } from "@/db";
import * as S from "@/db/schema";
import { getLite, eq, asc } from "@/lib/engine";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const id = Number(new URL(req.url).searchParams.get("story"));
  await getLite();
  const [s] = await db
    .select({
      id: S.stories.id,
      level: S.stories.level,
      levelName: S.stories.levelName,
      idx: S.stories.idx,
      title: S.stories.title,
      titleAr: S.stories.titleAr,
      book: S.stories.book,
      author: S.stories.author,
      startSec: S.stories.startSec,
      endSec: S.stories.endSec,
      grammar: S.stories.grammar,
      rule: S.stories.rule,
      ruleAr: S.stories.ruleAr,
    })
    .from(S.stories)
    .where(eq(S.stories.id, id));
  if (!s) return Response.json({ error: "not found" }, { status: 404 });
  const vocab = await db.select().from(S.vocab).where(eq(S.vocab.storyId, id)).orderBy(asc(S.vocab.sec));
  const sentences = await db
    .select()
    .from(S.sentences)
    .where(eq(S.sentences.storyId, id))
    .orderBy(asc(S.sentences.sec));
  return Response.json({ story: s, vocab, sentences });
}
