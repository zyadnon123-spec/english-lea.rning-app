import { db } from "@/db";
import * as S from "@/db/schema";
import { addDays, today, boostCard, touchActivity, eq, and, sql } from "@/lib/engine";

export const dynamic = "force-dynamic";

/** تسجيل إجابة واحدة: يحدّث نقاط الضعف وبطاقات المراجعة */
export async function POST(req: Request) {
  const { id, correct } = (await req.json()) as { id: number; correct: boolean };
  const [q] = await db.select().from(S.questions).where(eq(S.questions.id, id));
  if (!q) return Response.json({ error: "no question" }, { status: 404 });
  await touchActivity();
  const [st] = await db.select().from(S.stories).where(eq(S.stories.id, q.storyId));
  const tomorrow = addDays(today(), 1);

  let wk: { kind: string; key: string; label: string; labelAr: string } | null = null;
  let vocabRow: typeof S.vocab.$inferSelect | undefined;
  if (q.vocabTerm) {
    [vocabRow] = await db
      .select()
      .from(S.vocab)
      .where(and(eq(S.vocab.storyId, q.storyId), eq(S.vocab.term, q.vocabTerm)));
    wk = { kind: "word", key: q.vocabTerm, label: q.vocabTerm, labelAr: vocabRow?.ar ?? "" };
  } else if (q.grammarKey) {
    const g = st.grammar as { topic: string };
    wk = { kind: "grammar", key: q.grammarKey, label: g.topic || q.grammarKey, labelAr: "" };
  }
  if (wk) {
    const grammarSec = (st.grammar as { sec: number }).sec;
    await db
      .insert(S.weakness)
      .values({
        ...wk,
        storyId: q.storyId,
        sec: wk.kind === "word" ? (vocabRow?.sec ?? q.seekSec) : grammarSec || q.seekSec,
        attempts: 1,
        wrong: correct ? 0 : 1,
      })
      .onConflictDoUpdate({
        target: [S.weakness.kind, S.weakness.key],
        set: {
          attempts: sql`${S.weakness.attempts} + 1`,
          wrong: sql`${S.weakness.wrong} + ${correct ? 0 : 1}`,
          storyId: q.storyId,
          updatedAt: new Date(),
        },
      });
  }
  if (!correct) {
    if (vocabRow) await boostCard("word", vocabRow.id, q.storyId, tomorrow);
    else {
      const [sent] = await db
        .select()
        .from(S.sentences)
        .where(and(eq(S.sentences.storyId, q.storyId), eq(S.sentences.sec, q.seekSec)));
      if (sent) await boostCard("sentence", sent.id, q.storyId, tomorrow);
    }
  }
  return Response.json({ ok: true });
}
