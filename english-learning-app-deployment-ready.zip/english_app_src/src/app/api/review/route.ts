import { db } from "@/db";
import * as S from "@/db/schema";
import { addDays, today, getLite, touchActivity, eq, lte, asc, sql } from "@/lib/engine";

export const dynamic = "force-dynamic";

export async function GET() {
  await getLite();
  const t = today();
  const rows = await db
    .select({
      id: S.reviewCards.id,
      kind: S.reviewCards.kind,
      front: S.reviewCards.front,
      back: S.reviewCards.back,
      example: S.reviewCards.example,
      storyId: S.reviewCards.storyId,
      sourceSec: S.reviewCards.sourceSec,
      dueDate: S.reviewCards.dueDate,
      title: S.stories.title,
      idx: S.stories.idx,
      level: S.stories.level,
    })
    .from(S.reviewCards)
    .innerJoin(S.stories, eq(S.stories.id, S.reviewCards.storyId))
    .where(lte(S.reviewCards.dueDate, t))
    .orderBy(asc(S.reviewCards.dueDate), asc(S.reviewCards.id))
    .limit(40);
  const [due] = await db
    .select({ c: sql<number>`count(*)::int` })
    .from(S.reviewCards)
    .where(lte(S.reviewCards.dueDate, t));
  const [tm] = await db
    .select({ c: sql<number>`count(*)::int` })
    .from(S.reviewCards)
    .where(eq(S.reviewCards.dueDate, addDays(t, 1)));
  const [all] = await db.select({ c: sql<number>`count(*)::int` }).from(S.reviewCards);
  return Response.json({ cards: rows, dueTotal: due.c, tomorrow: tm.c, totalCards: all.c });
}

const INTERVAL = { hard: 1, ok: 3, easy: 7 } as const;

export async function POST(req: Request) {
  const { id, rating } = (await req.json()) as { id: number; rating: keyof typeof INTERVAL };
  const days = INTERVAL[rating];
  if (!days) return Response.json({ error: "bad rating" }, { status: 400 });
  await touchActivity();
  await db
    .update(S.reviewCards)
    .set({
      dueDate: addDays(today(), days),
      intervalDays: days,
      reps: sql`${S.reviewCards.reps} + 1`,
      lastRating: rating,
    })
    .where(eq(S.reviewCards.id, id));
  return Response.json({ ok: true, dueIn: days });
}
