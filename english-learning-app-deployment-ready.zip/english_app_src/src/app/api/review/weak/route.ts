import { db } from "@/db";
import * as S from "@/db/schema";
import { today, weakList, boostCard, getLite, eq, and } from "@/lib/engine";

export const dynamic = "force-dynamic";

/** زرار "راجعهم": يدخل نقاط الضعف في المراجعة ويجعلها مستحقة اليوم */
export async function POST() {
  await getLite();
  const t = today();
  const weak = await weakList(12);
  let n = 0;
  for (const w of weak) {
    if (w.kind === "word") {
      const [v] = await db
        .select()
        .from(S.vocab)
        .where(and(eq(S.vocab.storyId, w.storyId), eq(S.vocab.term, w.key)));
      if (v) {
        await boostCard("word", v.id, w.storyId, t);
        n++;
      }
    } else {
      const ss = await db
        .select()
        .from(S.sentences)
        .where(and(eq(S.sentences.storyId, w.storyId), eq(S.sentences.isKey, true)));
      for (const s of ss.slice(0, 3)) {
        await boostCard("sentence", s.id, w.storyId, t);
        n++;
      }
    }
  }
  return Response.json({ ok: true, added: n });
}
