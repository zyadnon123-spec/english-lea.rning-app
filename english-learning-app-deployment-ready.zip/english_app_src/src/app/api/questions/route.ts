import { db } from "@/db";
import * as S from "@/db/schema";
import { getLite, loadPlan, weakMap, pickQuestions, eq, inArray, sql, desc, and } from "@/lib/engine";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const sp = new URL(req.url).searchParams;
  const mode = sp.get("mode") ?? "practice";
  await getLite();
  const weak = await weakMap();

  if (mode === "practice") {
    const story = Number(sp.get("story"));
    const rows = await db.select().from(S.questions).where(eq(S.questions.storyId, story));
    const qs = pickQuestions(rows, 10, weak, new Set());
    return Response.json({ mode, storyId: story, questions: qs });
  }

  if (mode === "weak") {
    const w = await db.select().from(S.weakness).where(sql`${S.weakness.wrong} > 0`);
    const words = w.filter((x) => x.kind === "word").map((x) => x.key);
    const gk = w.filter((x) => x.kind === "grammar").map((x) => x.key);
    if (!words.length && !gk.length) return Response.json({ mode, questions: [] });
    const rows = await db
      .select()
      .from(S.questions)
      .where(
        sql`(${words.length ? sql`${S.questions.vocabTerm} in (${sql.join(words.map((x) => sql`${x}`), sql`,`)})` : sql`false`}) or (${gk.length ? sql`${S.questions.grammarKey} in (${sql.join(gk.map((x) => sql`${x}`), sql`,`)})` : sql`false`})`,
      );
    return Response.json({ mode, questions: pickQuestions(rows, 10, weak, new Set()) });
  }

  // quiz: اختبار اليوم أو الاختبار الشامل
  const p = await loadPlan();
  const day = p.active;
  if (!day) return Response.json({ error: "no active day" }, { status: 400 });
  const ids = day.storyIds as number[];
  const rows = await db.select().from(S.questions).where(inArray(S.questions.storyId, ids));
  const [last] = await db
    .select()
    .from(S.attempts)
    .where(and(eq(S.attempts.dayId, day.id)))
    .orderBy(desc(S.attempts.id))
    .limit(1);
  const prevWrong = new Set<number>(last ? ((last.wrongIds as number[]) ?? []) : []);
  const n = day.kind === "level_exam" ? 20 : 15;
  const qs = pickQuestions(rows, n, weak, prevWrong);
  const titles = p.all.filter((s) => ids.includes(s.id)).map((s) => ({ id: s.id, title: s.title, idx: s.idx }));
  return Response.json({
    mode: "quiz",
    dayId: day.id,
    dayNo: day.dayNo,
    kind: day.kind,
    level: day.level,
    retake: !!last,
    questions: qs,
    stories: titles,
  });
}
