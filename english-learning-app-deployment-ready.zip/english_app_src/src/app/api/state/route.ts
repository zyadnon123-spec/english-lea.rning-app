import { db } from "@/db";
import * as S from "@/db/schema";
import {
  loadPlan,
  restOf,
  streakOf,
  missedStudyDates,
  dueCount,
  eq,
  inArray,
  sql,
} from "@/lib/engine";

export const dynamic = "force-dynamic";

export async function GET() {
  const p = await loadPlan();
  const { settings, all, active, done, futureDays, totalDays, today } = p;
  if (!settings.started || !active) {
    return Response.json({ started: false, finished: settings.started && !active });
  }
  const rest = restOf(settings);
  const ids = active.storyIds as number[];
  const prog = await db.select().from(S.storyProgress).where(inArray(S.storyProgress.storyId, ids));
  const progMap = new Map(prog.map((x) => [x.storyId, x]));
  const stories =
    active.kind === "study"
      ? ids.map((id) => {
          const s = all.find((x) => x.id === id)!;
          const pr = progMap.get(id);
          return {
            id,
            title: s.title,
            titleAr: s.titleAr,
            idx: s.idx,
            level: s.level,
            startSec: s.startSec,
            endSec: s.endSec,
            durMin: Math.round(s.dur / 60),
            practiced: !!pr,
            bestScore: pr?.bestScore ?? 0,
          };
        })
      : [];
  const practiced = stories.filter((s) => s.practiced).length;
  const progress =
    active.kind === "study" ? Math.round((practiced / (stories.length + 1)) * 100) : 0;

  const missedAll = await missedStudyDates(settings.startDate, rest);
  const notes: string[] = [];
  if (active.multiplier < 1)
    notes.push("نتيجة اختبارك الأخير كانت أقل من 70% — خففنا يوم اليوم (×0.75) وأضفنا مراجعة لأجزاء الغلط.");
  else if (active.multiplier > 1)
    notes.push("أداؤك ممتاز (أكثر من 90%) — أطلنا يوم اليوم قليلًا (×1.25).");
  const lastDone = done[done.length - 1];
  const missedNow = missedAll.filter((d) => !lastDone?.completedDate || d > lastDone.completedDate);
  const finishDate = futureDays.length ? futureDays[futureDays.length - 1].date : active.scheduledDate;
  if (missedNow.length)
    notes.push(
      `فاتك ${missedNow.length} يوم — أعدنا توزيع الباقي من اليوم، وصار إجمالي الأيام ${totalDays} وتنتهي الخطة في ${finishDate}.`,
    );
  if (active.attempts > 0 && (active.bestScore ?? 0) < 70)
    notes.push(`آخر نتيجة ${active.bestScore}% — راجع أجزاء الغلط ثم أعد الاختبار (النجاح 70%).`);
  if (settings.planTotalSeen !== totalDays) {
    const msg =
      settings.planTotalSeen > 0
        ? `تحدّث إجمالي أيام الخطة من ${settings.planTotalSeen} إلى ${totalDays}.`
        : "";
    await db
      .update(S.settings)
      .set({ planTotalSeen: totalDays, planNote: msg || settings.planNote })
      .where(eq(S.settings.id, 1));
    if (msg) settings.planNote = msg;
  }
  if (settings.planNote && notes.length < 2) notes.push(settings.planNote);
  if (!notes.length)
    notes.push("الخطة متجددة: تتأكد حدود كل يوم من القصص الفعلية وتتعدل حسب نتائج اختباراتك وأيام الغياب.");

  const quizzes = await db
    .select({ avg: sql<number>`coalesce(round(avg(${S.attempts.pct})),-1)::int`, n: sql<number>`count(*)::int` })
    .from(S.attempts)
    .where(sql`${S.attempts.kind} in ('quiz','level')`);
  const levelDoneIds = new Set<number>();
  for (const d of done) if (d.kind === "study") (d.storyIds as number[]).forEach((i) => levelDoneIds.add(i));
  const levelStories = all.filter((s) => s.level === active.level);
  const [weakCount] = await db
    .select({ c: sql<number>`count(*)::int` })
    .from(S.weakness)
    .where(sql`${S.weakness.wrong} > 0`);
  const levelName =
    { A0: "الأبجديات", A1: "التأسيس", A2: "التواصل", B1: "الطلاقة", B2: "الثقة", C1: "الاحتراف" }[
      active.level
    ] ?? "";

  return Response.json({
    started: true,
    today,
    day: {
      id: active.id,
      dayNo: active.dayNo,
      kind: active.kind,
      level: active.level,
      levelName,
      plannedMin: active.plannedMin,
      targetMin: active.targetMin,
      multiplier: active.multiplier,
      scheduledDate: active.scheduledDate,
      attempts: active.attempts,
      bestScore: active.bestScore,
      stories,
      practiced,
      progress,
      examStories: active.kind === "level_exam" ? ids.length : 0,
      examList:
        active.kind === "level_exam"
          ? all.filter((s) => ids.includes(s.id)).map((s) => ({ id: s.id, idx: s.idx, title: s.title }))
          : [],
    },
    notes,
    stats: {
      streak: await streakOf(rest),
      avgQuiz: quizzes[0].avg,
      quizCount: quizzes[0].n,
      level: active.level,
      levelName,
      levelDone: levelStories.filter((s) => levelDoneIds.has(s.id)).length,
      levelTotal: levelStories.length,
    },
    review: { due: await dueCount(), weak: weakCount.c },
    totalDays,
    doneDays: done.length,
    finishDate,
    minutesPerDay: settings.minutesPerDay,
  });
}
