import { db } from "@/db";
import * as S from "@/db/schema";
import { loadPlan, restOf, missedStudyDates, weakList, streakOf, sql, desc } from "@/lib/engine";

export const dynamic = "force-dynamic";

export async function GET() {
  const p = await loadPlan();
  if (!p.settings.started) return Response.json({ started: false });
  const rest = restOf(p.settings);
  const days = await db.select().from(S.planDays);
  const dayNo = new Map(days.map((d) => [d.id, d.dayNo]));

  const calendar = [
    ...p.done.map((d) => ({
      dayNo: d.dayNo,
      state: "done" as const,
      date: d.completedDate ?? d.scheduledDate,
      kind: d.kind,
      level: d.level,
      score: d.bestScore,
    })),
    ...(p.active
      ? [
          {
            dayNo: p.active.dayNo,
            state: "today" as const,
            date: p.active.scheduledDate,
            kind: p.active.kind,
            level: p.active.level,
            score: p.active.bestScore,
          },
        ]
      : []),
    ...p.futureDays.map((d) => ({
      dayNo: d.dayNo,
      state: "next" as const,
      date: d.date,
      kind: d.kind,
      level: d.level,
      score: null as number | null,
    })),
  ];

  const qa = await db
    .select()
    .from(S.attempts)
    .where(sql`${S.attempts.kind} in ('quiz','level')`)
    .orderBy(desc(S.attempts.id))
    .limit(12);
  const scores = qa
    .reverse()
    .map((a) => ({ id: a.id, pct: a.pct, dayNo: dayNo.get(a.dayId ?? -1) ?? 0, kind: a.kind }));

  const weak = await weakList(20);
  const missed = await missedStudyDates(p.settings.startDate, rest);
  return Response.json({
    started: true,
    calendar,
    scores,
    weakWords: weak.filter((w) => w.kind === "word"),
    weakGrammar: weak.filter((w) => w.kind === "grammar"),
    totalDays: p.totalDays,
    doneDays: p.done.length,
    missed: missed.length,
    streak: await streakOf(rest),
    finishDate: calendar[calendar.length - 1]?.date,
  });
}
