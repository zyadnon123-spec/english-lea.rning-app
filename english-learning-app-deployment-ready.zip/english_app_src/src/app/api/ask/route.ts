import { db } from "@/db";
import * as S from "@/db/schema";
import { getLite, eq, asc } from "@/lib/engine";

export const dynamic = "force-dynamic";

const VIDEO = "https://www.youtube.com/watch?v=nSrjNHK6slw";

const STOP = new Set(
  "the and for with what how why does mean this that from about are was were you your have has into when where which who can will".split(" "),
);

function fmt(sec: number) {
  const h = Math.floor(sec / 3600);
  const m = Math.floor((sec % 3600) / 60);
  const s = sec % 60;
  return h ? `${h}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}` : `${m}:${String(s).padStart(2, "0")}`;
}

export async function POST(req: Request) {
  const { storyId, question } = (await req.json()) as { storyId: number; question: string };
  await getLite();
  const q = (question ?? "").trim().slice(0, 600);
  if (!q) return Response.json({ error: "اكتب سؤالك أولًا" }, { status: 400 });
  const [st] = await db.select().from(S.stories).where(eq(S.stories.id, storyId));
  if (!st) return Response.json({ error: "قصة غير موجودة" }, { status: 404 });
  const vocab = await db.select().from(S.vocab).where(eq(S.vocab.storyId, storyId)).orderBy(asc(S.vocab.sec));
  const lines = st.lines
    .split("\n")
    .map((l) => {
      const i = l.indexOf("|");
      return { sec: Number(l.slice(0, i)), text: l.slice(i + 1) };
    })
    .filter((l) => l.text);

  const key = process.env.GEMINI_API_KEY;
  if (key) {
    const excerpt = lines.map((l) => `[${fmt(l.sec)}] ${l.text}`).join("\n").slice(0, 16000);
    const prompt =
      `أنت مساعد لتعليم الإنجليزية لمتعلم عربي. السؤال عن مقطع واحد من فيديو تعليمي (طريقة TPRS) بعنوان القصة "${st.title}" ` +
      `من ${fmt(st.startSec)} إلى ${fmt(st.endSec)}.\n` +
      `أجب بالعربي ببساطة وبإيجاز، واعتمد فقط على هذا المقطع (الفيديو والنص المرفق). ` +
      `اذكر الوقت (mm:ss) الذي ورد فيه الجواب إن أمكن. إن لم يكن الجواب في المقطع فقل ذلك بصراحة.\n\n` +
      `نص المقطع (ترجمة تلقائية قد تحتوي أخطاء):\n${excerpt}\n\nسؤال المتعلم: ${q}`;
    const model = process.env.GEMINI_MODEL || "gemini-2.5-flash";
    const call = async (withVideo: boolean) => {
      const parts: unknown[] = [];
      if (withVideo)
        parts.push({
          fileData: { fileUri: VIDEO },
          videoMetadata: { startOffset: `${st.startSec}s`, endOffset: `${st.endSec}s` },
        });
      parts.push({ text: prompt });
      const r = await fetch(
        `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json", "x-goog-api-key": key },
          body: JSON.stringify({ contents: [{ parts }] }),
          signal: AbortSignal.timeout(60000),
        },
      );
      if (!r.ok) throw new Error(`gemini ${r.status}`);
      const j = (await r.json()) as {
        candidates?: { content?: { parts?: { text?: string }[] } }[];
      };
      const text = j.candidates?.[0]?.content?.parts?.map((p) => p.text ?? "").join("") ?? "";
      if (!text) throw new Error("empty");
      return text;
    };
    try {
      let text: string;
      let viaVideo = true;
      try {
        text = await call(true);
      } catch {
        viaVideo = false;
        text = await call(false);
      }
      return Response.json({ answer: text, source: viaVideo ? "gemini-video" : "gemini-text" });
    } catch {
      // نكمل بالبحث المحلي
    }
  }

  // بديل محلي: بحث في مفردات ونص القصة نفسها
  const words = (q.toLowerCase().match(/[a-z']{3,}/g) ?? []).filter((w) => !STOP.has(w));
  const vHits = vocab.filter(
    (v) => words.includes(v.term.toLowerCase()) || (q.includes(v.ar) && v.ar.length > 1),
  );
  const lHits = lines
    .map((l) => ({ ...l, score: words.filter((w) => l.text.toLowerCase().includes(w)).length }))
    .filter((l) => l.score > 0)
    .sort((a, b) => b.score - a.score || a.sec - b.sec)
    .slice(0, 4);
  let answer = "";
  if (vHits.length)
    answer +=
      "من مفردات هذه القصة:\n" +
      vHits.map((v) => `• ${v.term} = ${v.ar} (عند ${fmt(v.sec)}${v.exEn ? ` — "${v.exEn}"` : ""})`).join("\n") +
      "\n\n";
  if (lHits.length)
    answer +=
      "أقرب ما قيل في الفيديو:\n" +
      lHits.map((l) => `• [${fmt(l.sec)}] ${l.text}`).join("\n") +
      "\n\n";
  if (!answer) answer = "لم أجد في هذا المقطع ما يطابق سؤالك. جرّب كلمة إنجليزية من القصة أو من المفردات.\n\n";
  answer += key
    ? "(تعذّر الاتصال بـ Gemini الآن، فهذا بحث محلي في نص المقطع.)"
    : "(لتفعيل إجابات Gemini على نفس المقطع أضِف المتغير GEMINI_API_KEY، وحاليًا هذا بحث محلي في نص المقطع.)";
  return Response.json({
    answer,
    source: "local",
    hits: lHits.map((l) => l.sec),
  });
}
