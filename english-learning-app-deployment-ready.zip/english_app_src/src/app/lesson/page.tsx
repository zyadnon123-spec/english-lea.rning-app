"use client";
import { Suspense, useRef, useState } from "react";
import Link from "next/link";
import { useSearchParams } from "next/navigation";
import Shell, { Loading } from "@/components/Shell";
import YTPlayer from "@/components/YTPlayer";
import { fmtMin, fmtSec, post, useApi, useAppState } from "@/lib/client";

type LessonData = {
  story: {
    id: number;
    level: string;
    levelName: string;
    idx: number;
    title: string;
    titleAr: string;
    book: string;
    author: string;
    startSec: number;
    endSec: number;
    grammar: { topic: string; sec: number; examples: { en: string; ar: string }[] };
    rule: string;
    ruleAr: string;
  };
  vocab: { id: number; term: string; ar: string; sec: number; exEn: string; exAr: string; exSec: number }[];
  sentences: { id: number; en: string; ar: string; sec: number; isKey: boolean }[];
};

const TABS = [
  { k: "sum", n: "ملخص" },
  { k: "vocab", n: "مفردات" },
  { k: "gram", n: "قواعد" },
  { k: "ask", n: "اسأل" },
];

export default function LessonPage() {
  return (
    <Suspense fallback={<Shell active="lesson"><Loading /></Shell>}>
      <Lesson />
    </Suspense>
  );
}

function Lesson() {
  const sp = useSearchParams();
  const { state, loading } = useAppState();
  const [sel, setSel] = useState<number | null>(null);
  const [tab, setTab] = useState("sum");
  const [seek, setSeek] = useState<{ sec: number; key: number } | null>(null);
  const [showAll, setShowAll] = useState(false);
  const playerRef = useRef<HTMLDivElement>(null);

  const day = state?.day;
  const list =
    day?.kind === "study"
      ? day.stories.map((s) => ({ id: s.id, idx: s.idx, title: s.title, practiced: s.practiced }))
      : (day?.examList ?? []).map((s) => ({ ...s, practiced: false }));
  const paramId = Number(sp.get("story")) || 0;
  const defId = paramId || list.find((s) => !s.practiced)?.id || list[0]?.id || 0;
  const id = sel ?? defId;
  const { data } = useApi<LessonData>(id ? `/api/lesson?story=${id}` : null);
  const lesson = data && data.story.id === id ? data : null;

  const go = (sec: number) => {
    setSeek({ sec: Math.max(0, sec), key: Date.now() });
    playerRef.current?.scrollIntoView({ behavior: "smooth", block: "center" });
  };

  if (loading || !state || !day) return <Shell active="lesson"><Loading /></Shell>;
  const isExam = day.kind === "level_exam";
  const s = lesson?.story;

  return (
    <Shell active="lesson">
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h1 className="text-[20px] font-bold">
            {isExam ? "مراجعة المستوى" : `درس اليوم ${day.dayNo}`}
          </h1>
          {!isExam && <span className="text-[12px] text-muted">{fmtMin(day.plannedMin)}</span>}
        </div>

        {isExam && (
          <div className="rounded-2xl border border-accent/40 bg-accent-soft p-4 text-[13px] leading-6">
            اليوم هو <b>الاختبار الشامل لمستوى {day.level}</b>. راجع أي قصة من القائمة ثم ابدأ الاختبار (20 سؤالًا، النجاح 70%).
          </div>
        )}

        {list.length > 0 &&
          (list.length <= 5 ? (
            <div className="scrollx -mx-4 flex gap-2 px-4">
              {list.map((it) => (
                <button
                  key={it.id}
                  onClick={() => {
                    setSel(it.id);
                    setSeek(null);
                  }}
                  className={`min-h-[44px] shrink-0 rounded-full border px-4 text-[13px] font-semibold ${
                    it.id === id ? "border-brand bg-brand text-white" : "border-line bg-white"
                  }`}
                >
                  قصة {it.idx} {it.practiced ? "✓" : ""}
                </button>
              ))}
            </div>
          ) : (
            <select
              value={id}
              onChange={(e) => {
                setSel(Number(e.target.value));
                setSeek(null);
              }}
              className="ltr min-h-[44px] w-full rounded-xl border border-line bg-white px-3 text-[14px]"
            >
              {list.map((it) => (
                <option key={it.id} value={it.id}>
                  {it.idx}. {it.title}
                </option>
              ))}
            </select>
          ))}

        {!lesson || !s ? (
          <Loading />
        ) : (
          <>
            <div ref={playerRef}>
              <YTPlayer key={s.id} start={s.startSec} end={s.endSec} seek={seek} />
            </div>

            <div className="card p-4">
              <div className="flex items-center gap-2 text-[12px] font-semibold text-accent">
                <span className="rounded-full bg-accent-soft px-2.5 py-0.5">
                  {s.level} · قصة {s.idx}
                </span>
                <span className="text-muted">
                  {fmtSec(s.startSec)} – {fmtSec(s.endSec)} · {Math.round((s.endSec - s.startSec) / 60)} د
                </span>
              </div>
              <h2 className="ltr mt-2 text-[20px] font-bold leading-8">{s.title}</h2>
              {s.titleAr && <p className="text-[14px] text-muted">{s.titleAr}</p>}
              {s.book && (
                <p className="ltr mt-1 text-[12px] text-muted">
                  📖 {s.book}
                  {s.author ? ` — ${s.author}` : ""}
                </p>
              )}
            </div>

            <div className="grid grid-cols-4 gap-1 rounded-2xl border border-line bg-white p-1">
              {TABS.map((t) => (
                <button
                  key={t.k}
                  onClick={() => setTab(t.k)}
                  className={`min-h-[44px] rounded-xl text-[14px] font-semibold ${
                    tab === t.k ? "bg-brand text-white" : "text-muted"
                  }`}
                >
                  {t.n}
                </button>
              ))}
            </div>

            {tab === "sum" && (
              <div className="space-y-3 fade-up">
                <p className="text-[12px] text-muted">جمل المدرب الرئيسية في القصة، بالترتيب (اضغط للعودة للفيديو):</p>
                {(showAll ? lesson.sentences : lesson.sentences.filter((x) => x.isKey)).map((x) => (
                  <button key={x.id} onClick={() => go(x.sec)} className="card block w-full p-3.5 text-right">
                    <p className="ltr text-[15px] font-semibold leading-7">{x.en}</p>
                    <p className="mt-1 text-[13px] text-muted">{x.ar}</p>
                    <span className="mt-1.5 inline-block rounded-full bg-brand-soft px-2.5 py-0.5 text-[11px] font-bold text-brand">
                      ▶ {fmtSec(x.sec)}
                    </span>
                  </button>
                ))}
                <button className="btn btn-ghost w-full" onClick={() => setShowAll((v) => !v)}>
                  {showAll ? "عرض الجمل الرئيسية فقط" : `عرض كل جمل القصة (${lesson.sentences.length})`}
                </button>
                {s.rule && (
                  <div className="rounded-2xl border border-accent/40 bg-accent-soft p-4">
                    <p className="text-[12px] font-bold text-accent">قاعدة اليوم من المدرب</p>
                    <p className="ltr mt-1 text-[15px] font-semibold">{s.rule}</p>
                    {s.ruleAr && <p className="mt-1 text-[13px] text-muted">{s.ruleAr}</p>}
                  </div>
                )}
              </div>
            )}

            {tab === "vocab" && (
              <div className="space-y-2.5 fade-up">
                {lesson.vocab.length === 0 && <p className="text-sm text-muted">لم تُستخرج مفردات لهذه القصة.</p>}
                {lesson.vocab.map((v) => (
                  <div key={v.id} className="card p-3.5">
                    <div className="flex items-center justify-between gap-2">
                      <div className="flex items-baseline gap-3">
                        <span className="ltr text-[18px] font-bold text-brand">{v.term}</span>
                        <span className="text-[16px] font-semibold">{v.ar}</span>
                      </div>
                      <button
                        onClick={() => go(v.sec)}
                        className="min-h-[36px] shrink-0 rounded-full bg-brand-soft px-3 text-[12px] font-bold text-brand"
                      >
                        ▶ {fmtSec(v.sec)}
                      </button>
                    </div>
                    {v.exEn && (
                      <button onClick={() => go(v.exSec)} className="mt-2 block w-full text-right">
                        <p className="ltr text-[13px] text-ink/80">“{v.exEn}”</p>
                        <p className="text-[12px] text-muted">{v.exAr}</p>
                      </button>
                    )}
                  </div>
                ))}
              </div>
            )}

            {tab === "gram" && (
              <div className="space-y-3 fade-up">
                <div className="card p-4">
                  <p className="text-[12px] font-bold text-accent">قاعدة القصة (من ملخص المدرب في آخر القصة)</p>
                  <p className="ltr mt-1 text-[20px] font-bold text-brand">{s.grammar.topic || "—"}</p>
                  <p className="mt-2 text-[12px] leading-5 text-muted">
                    الشرح العربي للقاعدة موجود في الفيديو نفسه — اضغط للاستماع عند موضعه.
                  </p>
                  {s.grammar.sec > 0 && (
                    <button className="btn btn-primary mt-3 w-full" onClick={() => go(s.grammar.sec - 3)}>
                      ▶ اسمع الشرح عند {fmtSec(s.grammar.sec)}
                    </button>
                  )}
                </div>
                {s.grammar.examples.map((e, i) => (
                  <div key={i} className="card p-3.5">
                    <p className="ltr text-[15px] font-semibold leading-7">{e.en}</p>
                    <p className="mt-1 text-[13px] text-muted">{e.ar}</p>
                  </div>
                ))}
              </div>
            )}

            {tab === "ask" && <Ask storyId={s.id} onSeek={go} />}

            <div className="grid grid-cols-2 gap-2.5 pt-1">
              <Link href={`/practice?story=${s.id}`} className="btn btn-primary">
                تدريب القصة
              </Link>
              <Link href="/quiz" className="btn btn-accent">
                اختبار اليوم
              </Link>
            </div>
          </>
        )}
      </div>
    </Shell>
  );
}

function Ask({ storyId, onSeek }: { storyId: number; onSeek: (s: number) => void }) {
  const [q, setQ] = useState("");
  const [busy, setBusy] = useState(false);
  const [res, setRes] = useState<{ answer: string; source: string; hits?: number[] } | null>(null);
  const [err, setErr] = useState("");

  const send = async () => {
    if (!q.trim()) return;
    setBusy(true);
    setErr("");
    setRes(null);
    try {
      setRes(await post("/api/ask", { storyId, question: q }));
    } catch {
      setErr("تعذّر إرسال السؤال، حاول مرة أخرى.");
    }
    setBusy(false);
  };

  return (
    <div className="space-y-3 fade-up">
      <p className="text-[13px] leading-6 text-muted">
        اسأل أي سؤال عن هذا المقطع بالتحديد (كلمة، جملة، قاعدة). يُرسل سؤالك إلى Gemini مع نفس مقطع الفيديو.
      </p>
      <textarea
        value={q}
        onChange={(e) => setQ(e.target.value)}
        rows={3}
        placeholder="مثال: إيش معنى كلمة smoke وكيف استخدمها؟"
        className="w-full rounded-xl border border-line bg-white p-3 text-[15px] outline-none focus:border-brand"
      />
      <button className="btn btn-primary w-full" disabled={busy || !q.trim()} onClick={send}>
        {busy ? "جارِ التفكير…" : "اسأل Gemini"}
      </button>
      {err && <p className="text-sm text-bad">{err}</p>}
      {res && (
        <div className="card p-4">
          <p className="whitespace-pre-wrap text-[14px] leading-7">{res.answer}</p>
          <p className="mt-2 text-[11px] text-muted">
            {res.source === "gemini-video"
              ? "الإجابة من Gemini على نفس مقطع الفيديو"
              : res.source === "gemini-text"
                ? "الإجابة من Gemini على نص المقطع"
                : "بحث محلي في نص المقطع"}
          </p>
          {res.hits && res.hits.length > 0 && (
            <div className="mt-2 flex flex-wrap gap-2">
              {res.hits.map((h) => (
                <button key={h} onClick={() => onSeek(h)} className="rounded-full bg-brand-soft px-3 py-1 text-[12px] font-bold text-brand">
                  ▶ {fmtSec(h)}
                </button>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
