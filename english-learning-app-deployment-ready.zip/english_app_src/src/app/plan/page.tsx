"use client";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import Shell, { Loading } from "@/components/Shell";
import { fmtDate, fmtMin, post, useApi } from "@/lib/client";

type PlanData = {
  started: boolean;
  minutes: number;
  rest: number[];
  roughTotal: number;
  totalDays: number;
  finishDate?: string;
  analyzed: number;
  preview: {
    dayNo: number;
    date: string;
    level: string;
    kind: string;
    plannedMin: number;
    stories: number;
    titles: string[];
  }[];
};

const TIMES = [
  { v: 60, label: "ساعة", sub: "~60 دقيقة" },
  { v: 120, label: "ساعتين", sub: "~120 دقيقة" },
  { v: 180, label: "3 ساعات", sub: "~180 دقيقة" },
  { v: 0, label: "مرن", sub: "~45 دقيقة وتتعدّل" },
];
const WEEK = [
  { d: 6, n: "السبت" },
  { d: 0, n: "الأحد" },
  { d: 1, n: "الإثنين" },
  { d: 2, n: "الثلاثاء" },
  { d: 3, n: "الأربعاء" },
  { d: 4, n: "الخميس" },
  { d: 5, n: "الجمعة" },
];

export default function PlanPage() {
  const router = useRouter();
  const [init, setInit] = useState(false);
  const [minutes, setMinutes] = useState(60);
  const [rest, setRest] = useState<number[]>([5]);
  const [saving, setSaving] = useState(false);
  const url = init ? `/api/plan?minutes=${minutes}&rest=${rest.join(",")}` : "/api/plan";
  const { data } = useApi<PlanData>(url);

  useEffect(() => {
    if (data && !init) {
      setMinutes(data.minutes);
      setRest(data.started ? data.rest : [5]);
      setInit(true);
    }
  }, [data, init]);

  const toggle = (d: number) => setRest((r) => (r.includes(d) ? r.filter((x) => x !== d) : [...r, d]));

  const start = async () => {
    setSaving(true);
    await post("/api/plan", { minutes, rest });
    router.push("/");
  };

  return (
    <Shell hideNav title="الخطة الذكية" back={data?.started ? "/" : undefined}>
      {!data ? (
        <Loading text="نجهّز خطتك من القصص الحقيقية…" />
      ) : (
        <div className="space-y-5 pb-4">
          <div className="rounded-2xl bg-brand p-5 text-white">
            <p className="text-[13px] opacity-80">فيديو 100:42:16 — 6 مستويات</p>
            <h2 className="mt-1 text-[22px] font-bold leading-9">ابنِ خطتك ونحن نقسّم الفيديو على أيامك</h2>
            <p className="mt-2 text-[13px] leading-6 opacity-90">
              كل يوم ينتهي عند آخر قصة كاملة أقرب لوقتك. وتتجدد الخطة تلقائيًا حسب نتائج اختباراتك وأيام غيابك.
            </p>
          </div>

          <section>
            <h3 className="mb-2 text-[15px] font-bold">كم وقتك اليومي؟</h3>
            <div className="grid grid-cols-2 gap-2.5">
              {TIMES.map((t) => {
                const on = minutes === t.v;
                return (
                  <button
                    key={t.v}
                    onClick={() => setMinutes(t.v)}
                    className={`min-h-[64px] rounded-2xl border px-3 py-2 text-right transition ${
                      on ? "border-brand bg-brand text-white" : "border-line bg-white"
                    }`}
                  >
                    <div className="text-[17px] font-bold">{t.label}</div>
                    <div className={`text-[12px] ${on ? "opacity-85" : "text-muted"}`}>{t.sub}</div>
                  </button>
                );
              })}
            </div>
          </section>

          <section>
            <h3 className="mb-2 text-[15px] font-bold">أيام الراحة</h3>
            <div className="flex flex-wrap gap-2">
              {WEEK.map((w) => {
                const on = rest.includes(w.d);
                return (
                  <button
                    key={w.d}
                    onClick={() => toggle(w.d)}
                    className={`min-h-[44px] rounded-full border px-4 text-[14px] font-semibold ${
                      on ? "border-accent bg-accent text-white" : "border-line bg-white"
                    }`}
                  >
                    {w.n}
                  </button>
                );
              })}
            </div>
            <p className="mt-2 text-[12px] text-muted">أيام الراحة لا تُحسب غيابًا ولا تقطع الأيام المتواصلة.</p>
          </section>

          <section>
            <h3 className="mb-2 text-[15px] font-bold">معاينة أول 3 أيام</h3>
            <div className="space-y-2.5">
              {data.preview.map((d) => (
                <div key={d.dayNo} className="card p-3.5">
                  <div className="flex items-center justify-between">
                    <span className="text-[15px] font-bold">اليوم {d.dayNo}</span>
                    <span className="rounded-full bg-brand-soft px-3 py-1 text-[12px] font-bold text-brand">
                      {fmtMin(d.plannedMin)}
                    </span>
                  </div>
                  <p className="mt-1 text-[12px] text-muted">
                    {fmtDate(d.date)} · {d.stories} {d.stories > 2 ? "قصص" : d.stories === 2 ? "قصتان" : "قصة"} ·{" "}
                    {d.level}
                  </p>
                  <p className="ltr mt-2 text-[13px] text-ink/80">{d.titles.join("  •  ")}</p>
                </div>
              ))}
            </div>
          </section>

          <section className="card space-y-1.5 p-4 text-[13px] leading-6">
            <p>
              <b>تقدير أولي</b> من حدود المستويات: نحو <b>{data.roughTotal}</b> يومًا.
            </p>
            <p>
              <b>بعد تحليل القصص الفعلية</b> ({data.analyzed} قصة بحدودها الدقيقة): <b>{data.totalDays}</b> يومًا
              {data.finishDate ? ` — تنتهي ${fmtDate(data.finishDate, { weekday: undefined })}` : ""}.
            </p>
            <p className="text-muted">الانتقال لمستوى جديد يتطلب اختبارًا شاملًا (النجاح 70%).</p>
          </section>

          <button className="btn btn-primary w-full text-[16px]" disabled={saving} onClick={start}>
            {data.started ? "حفظ التعديل" : "ابدأ الخطة"}
          </button>
        </div>
      )}
    </Shell>
  );
}
