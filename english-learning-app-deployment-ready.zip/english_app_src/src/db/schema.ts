import {
  pgTable,
  serial,
  integer,
  text,
  real,
  jsonb,
  timestamp,
  boolean,
  uniqueIndex,
  index,
} from "drizzle-orm/pg-core";

/** القصص (210 قصة = 35 لكل مستوى) — مستخرجة من ترجمة الفيديو نفسه */
export const stories = pgTable("stories", {
  id: integer("id").primaryKey(),
  level: text("level").notNull(),
  levelName: text("level_name").notNull(),
  idx: integer("idx").notNull(),
  title: text("title").notNull(),
  titleAr: text("title_ar").notNull().default(""),
  book: text("book").notNull().default(""),
  author: text("author").notNull().default(""),
  startSec: integer("start_sec").notNull(),
  endSec: integer("end_sec").notNull(),
  grammar: jsonb("grammar").notNull(),
  rule: text("rule").notNull().default(""),
  ruleAr: text("rule_ar").notNull().default(""),
  lines: text("lines").notNull().default(""),
});

export const vocab = pgTable(
  "vocab",
  {
    id: serial("id").primaryKey(),
    storyId: integer("story_id").notNull(),
    term: text("term").notNull(),
    ar: text("ar").notNull(),
    sec: integer("sec").notNull(),
    exEn: text("ex_en").notNull().default(""),
    exAr: text("ex_ar").notNull().default(""),
    exSec: integer("ex_sec").notNull().default(0),
  },
  (t) => [index("vocab_story_idx").on(t.storyId)],
);

export const sentences = pgTable(
  "sentences",
  {
    id: serial("id").primaryKey(),
    storyId: integer("story_id").notNull(),
    en: text("en").notNull(),
    ar: text("ar").notNull(),
    sec: integer("sec").notNull(),
    isKey: boolean("is_key").notNull().default(false),
  },
  (t) => [index("sent_story_idx").on(t.storyId)],
);

export const questions = pgTable(
  "questions",
  {
    id: serial("id").primaryKey(),
    storyId: integer("story_id").notNull(),
    kind: text("kind").notNull(),
    sub: text("sub").notNull().default(""),
    prompt: text("prompt").notNull(),
    promptAr: text("prompt_ar").notNull().default(""),
    options: jsonb("options").notNull(),
    answer: text("answer").notNull(),
    explanation: text("explanation").notNull(),
    seekSec: integer("seek_sec").notNull(),
    vocabTerm: text("vocab_term"),
    grammarKey: text("grammar_key"),
  },
  (t) => [index("q_story_idx").on(t.storyId)],
);

export const settings = pgTable("settings", {
  id: integer("id").primaryKey(),
  started: boolean("started").notNull().default(false),
  minutesPerDay: integer("minutes_per_day").notNull().default(60), // 0 = مرن
  restDays: jsonb("rest_days").notNull().default([]), // 0=أحد ... 6=سبت
  startDate: text("start_date"),
  nextMultiplier: real("next_multiplier").notNull().default(1),
  planTotalSeen: integer("plan_total_seen").notNull().default(0),
  planNote: text("plan_note").notNull().default(""),
});

export const planDays = pgTable("plan_days", {
  id: serial("id").primaryKey(),
  dayNo: integer("day_no").notNull(),
  kind: text("kind").notNull().default("study"), // study | level_exam
  level: text("level").notNull(),
  storyIds: jsonb("story_ids").notNull(),
  targetMin: integer("target_min").notNull(),
  plannedMin: integer("planned_min").notNull(),
  multiplier: real("multiplier").notNull().default(1),
  status: text("status").notNull().default("active"), // active | done
  scheduledDate: text("scheduled_date").notNull(),
  completedDate: text("completed_date"),
  firstScore: integer("first_score"),
  bestScore: integer("best_score"),
  attempts: integer("attempts").notNull().default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const storyProgress = pgTable("story_progress", {
  storyId: integer("story_id").primaryKey(),
  practicedAt: timestamp("practiced_at").notNull().defaultNow(),
  bestScore: integer("best_score").notNull().default(0),
});

export const attempts = pgTable("attempts", {
  id: serial("id").primaryKey(),
  dayId: integer("day_id"),
  kind: text("kind").notNull(), // practice | quiz | level
  storyId: integer("story_id"),
  score: integer("score").notNull(),
  total: integer("total").notNull(),
  pct: integer("pct").notNull(),
  wrongIds: jsonb("wrong_ids").notNull().default([]),
  date: text("date").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const weakness = pgTable(
  "weakness",
  {
    id: serial("id").primaryKey(),
    kind: text("kind").notNull(), // word | grammar
    key: text("key").notNull(),
    label: text("label").notNull(),
    labelAr: text("label_ar").notNull().default(""),
    storyId: integer("story_id").notNull(),
    sec: integer("sec").notNull().default(0),
    attempts: integer("attempts").notNull().default(0),
    wrong: integer("wrong").notNull().default(0),
    updatedAt: timestamp("updated_at").notNull().defaultNow(),
  },
  (t) => [uniqueIndex("weak_uq").on(t.kind, t.key)],
);

export const reviewCards = pgTable(
  "review_cards",
  {
    id: serial("id").primaryKey(),
    kind: text("kind").notNull(), // word | sentence
    refId: integer("ref_id").notNull(),
    storyId: integer("story_id").notNull(),
    front: text("front").notNull(),
    back: text("back").notNull(),
    example: text("example").notNull().default(""),
    sourceSec: integer("source_sec").notNull().default(0),
    dueDate: text("due_date").notNull(),
    intervalDays: integer("interval_days").notNull().default(0),
    reps: integer("reps").notNull().default(0),
    lastRating: text("last_rating"),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [uniqueIndex("card_uq").on(t.kind, t.refId)],
);

export const activity = pgTable("activity", {
  date: text("date").primaryKey(),
  actions: integer("actions").notNull().default(0),
});
